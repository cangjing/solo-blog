title: Firewalld防火墙实战
date: '2019-12-14 10:41:21'
updated: '2019-12-14 10:42:59'
tags: [安全]
permalink: /articles/2019/12/14/1576291281619.html
---
# 防火墙基本概述
>RHEL/CentOS 7系统中集成了多款防火墙管理工具，其中Firewalld（Dynamic Firewall Manager of Linux systemsLinux系统的动态防火墙管理器）服务是默认的防火墙配置管理工具，它拥有基于CLI（命令行界面）和基于GUI（图形用户界面）的两种管理方式。

- [ ] firewalld与iptables的不同点：
```
1、firewalld可以动态修改单条规则，而不需要像iptables那样，在修改了规则后必须得全部刷新才可以生效； 
2、firewalld在使用上要比iptables人性化很多，即使不明白"四表五链"而且对TCP/IP协议也不理解也可以实现大部分功能； 
四表：
	raw mangle nat filter
五链：
	INPUT OUTPUT FORWARD PREROUTEING POSTROUTING
3、firewalld跟iptables比起来，不好的地方是每个服务都需要去设置才能放行，因为默认是拒绝。而iptables里默认是每个服务是允许，需要拒绝的才去限制； 
4、firewalld加入了区域zone的概念。
```
***

# firewalld的工作过程

firewalld将所有传入流量划分区域，每个区域都有自己的一套规则。为检查哪个区域用于传入连接。firewalld使用以下逻辑，第一个匹配规则胜出：

1、传入包的源地址与区域的某个源规则设置匹配，该包将通过该区域进行路由。

2、包的传入接口与区域的过滤器设置匹配，则将使用该区域。

3、否则将使用默认区域。默认区域不是单独的区域，而是指向系统上定义的某个其他区域。

除非管理员NetworkManager配置所覆盖，否则，任何新网络接口的默认区域都将设置为public区域。

对于一个接收到的请求具体使用哪个zone，firewalld是通过三种方式来判断的：\
1、source，来源地址\
2、Interface，接收请求的网卡\
3、firewalld配置的默认区域（zone）\
这三个方式的优先级按顺序依次降低，也就是说如果按照source可以找到就不会再按interface去找，如果前两个都找不到才会使用第三个默认区域。


**Firewalld工作流程图**

![image.png](https://img.hacpai.com/file/2019/12/image-b99e3592.png)




## 防火墙区域概述

>简单来说，区域就是Firewalld预先准备了几套防火墙策略集合（策略模板）,用户可以根据生产场景的不同而选择合适的策略集合，从而实现防火墙策略之间的快速切换。



参数----------------	 | 	作用
---|---
trusted （信任） |允许所有的数据包流入与流出
home（家庭）	 |  拒绝流入的流量，除非与流出的流量相关；而如果流量与ssh、mdns、ipp-client、amba-client与dhcpv6-client服务相关，则允许流量
internal（内部） |等同于home区域
work（工作） | 拒绝流入的流量，除非与流出的流量数相关；而如果流量与ssh、ipp-client与dhcpv6-client服务相关，则允许流量
public（公共） |拒绝流入的流量，除非与流出的流量相关；而如果流量与ssh、dhcpv6-client服务相关，则允许流量
external（外部）| 拒绝流入的流量，除非与流出的流量相关；而如果流量与ssh服务相关，则允许流量
dmz（非军事区）|拒绝流入的流量，除非与流出的流量相关；而如果流量与ssh服务相关，则允许流量
block（限制） |拒绝流入的流量，除非与流出的流量相关
drop（丢弃）	|拒绝流入的流量，除非与流出的流量相关


- [ ] Firewalld相关配置文件
```
默认定义的区域模板配置文件/usr/lib/firewalld 
存储规则配置文件 /etc/firewalld/
```
***
```
[root@liudada zones]# firewall-cmd --list-all 
drop (active)
  target: DROP
  icmp-block-inversion: no
  interfaces: eth0
  sources: 
  services: 
  ports: 
  protocols: 
  masquerade: no
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules:
```
解释
```
Target：目标
icmp-block-inversion：ICMP协议类型黑白名单开关（yes/no）
Interfaces：关联的网卡接口
sources：来源，可以是IP地址，也可以是mac地址
services：允许的服务
ports：允许的目标端口，即本地开放的端口
protocols：允许通过的协议
masquerade：是否允许伪装（yes/no），可改写来源IP地址及mac地址
forward-ports：允许转发的端口
source-ports：允许的来源端口
icmp-blocks：可添加ICMP类型，当icmp-block-inversion为no时，这些ICMP类型被拒绝；当icmp-block-inversion为yes时，这些ICMP类型被允许。
rich rules：富规则，即更细致、更详细的防火墙规则策略，它的优先级在所有的防火墙策略中也是最高的。
```
***



# Firewalld操作与配置
## 1.服务操作
启动服务：
```
[root@web01 ~]# systemctl start firewalld
这里不用担心启用了防火墙以后无法通过ssh远程，22端口默认加入了允许规则

#加入开机自启
[root@web01 ~]# systemctl enable firewalld

#关闭开机自启
[root@web01 ~]# systemctl disable firewalld


停止服务：
[root@web01 ~]# systemctl stop firewalld

重启服务：
[root@web01 ~]# systemctl restart firewalld

查看服务状态：
[root@web01 ~]# systemctl status firewalld
```

## 2.配置文件说明
firewalld 存放配置文件有两个目录，`/usr/lib/firewalld` 和 `/etc/firewalld`，前者存放了一些默认的文件，后者主要是存放用户自定义的数据，所以我们添加的service或者rule都在后者下面进行。

`server` 文件夹存储服务数据，就是一组定义好的规则。

`zones` 存储区域规则

`firewalld.conf` 默认配置文件，可以设置默认使用的区域，默认区域为 public，对应 zones目录下的 public.xml

## 三.命令
这里需要首先说明的是，在执行命令时，如果没有带 `--permanent` 参数表示配置立即生效，但是不会对该配置进行存储，相当于重启服务器就会丢失。如果带上则会将配置存储到配置文件，，但是这种仅仅是将配置存储到文件，却并不会实时生效，需要执行 `firewall-cmd --reload` 命令重载配置才会生效。


### 1、防火墙基本应用
```
1.重载防火墙配置
firewall-cmd --reload

2.查看防火墙运行状态
firewall-cmd --state

3.查看默认区域的设置
firewall-cmd --list-all
```

### 2、防火墙应急模式

启动关闭firewalld防火墙服务的应急状况模式，远程连接服务器时请慎用
```
firewall-cmd --panic-on  # 拒绝所有流量，远程连接会立即断开，只有本地能登陆
firewall-cmd --panic-off  # 取消应急模式，但需要重启firewalld后才可以远程ssh
firewall-cmd --query-panic  # 查看是否为应急模式
```
### 3、服务操作
```
firewall-cmd --add-service=<service name> #添加服务
firewall-cmd --remove-service=<service name> #移除服务
```
### 4、端口操作
```
firewall-cmd --add-port=<port>/<protocol> #添加端口/协议（TCP/UDP）
firewall-cmd --remove-port=<port>/<protocol> #移除端口/协议（TCP/UDP）
firewall-cmd --list-ports #查看开放的端口
```
### 5、协议
```
firewall-cmd --add-protocol=<protocol> # 允许协议 (例：icmp，即允许ping)
firewall-cmd --remove-protocol=<protocol> # 取消协议
firewall-cmd --list-protocols # 查看允许的协议
```
***
# 实验
**实验环境**
```
[root@web01 ~]# uname -a
Linux web01 3.10.0-1062.4.3.el7.x86_64 #1 SMP Wed Nov 13 23:58:53 UTC 2019 x86_64 x86_64 x86_64 GNU/Linux
[root@web01 ~]# 
[root@web01 ~]# cat /etc/centos-release
CentOS Linux release 7.7.1908 (Core)
```

**服务器**
```
主机web01 ip/192.168.4.61 服务/nginx、firewalld  
主机web02 ip/192.168.4.62
主机web03 ip/192.168.4.63
```

## web01开启防火墙及基本配置

```
#开启防护墙
[root@web01 ~]# systemctl start firewalld
[root@web01 ~]# firewall-cmd --state 
running

#查看默认区域(public默认开放ssh)
[root@web01 ~]# firewall-cmd --get-default-zone 
public

#修改默认区域为drop
[root@web01 ~]# firewall-cmd --set-default-zone=drop
success
[root@web01 ~]# firewall-cmd --get-default-zone 
drop

#查看drop区域信息(什么都没有)
[root@web01 ~]# firewall-cmd --list-all
drop
  target: DROP
  icmp-block-inversion: no
  interfaces: 
  sources: 
  services: 
  ports: 
  protocols: 
  masquerade: no
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules: 

drop区域什么服务都没有，网卡也没有绑定。因此绑定网卡到drop区域

#绑定网卡到drop区域
[root@web01 ~]# firewall-cmd --add-interface=eth0 
success
[root@web01 ~]# firewall-cmd --list-all
drop (active)
  target: DROP
  icmp-block-inversion: no
  interfaces: eth0
...
...
```
> 上面操作我把默认区域更换成了drop区域，只绑定了网卡什么服务都没有开启，因此这台服务器上的业务内外网都是访问不了的，下面根据上面的说明一一操作


## 1、防火墙应急模式

启动关闭firewalld防火墙服务的应急状况模式，远程连接服务器时请慎用

firewall-cmd --panic-on  

![image.png](https://img.hacpai.com/file/2019/12/image-17f5fffd.png)


>开启后拒绝所有流量，远程连接会立即断开，只有本地能登陆

firewall-cmd --panic-off  

![image.png](https://img.hacpai.com/file/2019/12/image-09ad8e6f.png)


>取消应急模式，但需要重启firewalld后才可以远程ssh,因为配置了默认区域为drop，在远程连接的时候需要开放22端口才可以

firewall-cmd --query-panic  # 查看是否为应急模式
```
[root@web01 ~]# firewall-cmd --query-panic 
no
```

## 2、服务操作

firewall-cmd --add-service=<service name> #添加服务\
firewall-cmd --remove-service=<service name> #移除服务

### 开放http服务
```
[root@web01 ~]# firewall-cmd --add-service=http --permanent 
success
[root@web01 ~]# firewall-cmd --reload
```
查看开放的服务
```
[root@web01 ~]# firewall-cmd --list-services 
http
```

测试：web02或03上curl
```
[root@web02 ~]# curl -I -s 192.168.4.61
HTTP/1.1 200 OK
Server: nginx/1.16.1
Date: Fri, 13 Dec 2019 07:07:33 GMT
```

### 移除http服务
```
[root@web01 ~]# firewall-cmd --remove-service=http --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```


测试： curl没响应

![image.png](https://img.hacpai.com/file/2019/12/image-8edda062.png)



## 3、端口操作

firewall-cmd --add-port=<port>/<protocol> #添加端口/协议（TCP/UDP）\
firewall-cmd --remove-port=<port>/<protocol> #移除端口/协议（TCP/UDP）\
firewall-cmd --list-ports #查看开放的端口

### 开放80端口
```
[root@web01 ~]# firewall-cmd --add-port=80/tcp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```

测试：web02或03上curl
```
[root@web02 ~]# curl -I -s 192.168.4.61
HTTP/1.1 200 OK
Server: nginx/1.16.1
Date: Fri, 13 Dec 2019 07:04:18 GMT
```

查看开放的端口
```
[root@web01 ~]# firewall-cmd --list-ports
22/tcp 80/tcp
```


### 移除80端口

```
[root@web01 ~]# firewall-cmd --remove-port=80/tcp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```
## 4、协议操作
firewall-cmd --add-protocol=<protocol> # 允许协议 (例：icmp，即允许ping)\
firewall-cmd --remove-protocol=<protocol> # 取消协议\
firewall-cmd --list-protocols # 查看允许的协议

### 添加协议

```
[root@web01 ~]# firewall-cmd --add-protocol=icmp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```

查看允许的协议
```
[root@web01 ~]# firewall-cmd --list-protocols
icmp
```
测试 
```
[root@web02 ~]# ping 192.168.4.61
PING 192.168.4.61 (192.168.4.61) 56(84) bytes of data.
64 bytes from 192.168.4.61: icmp_seq=1 ttl=64 time=0.523 ms
64 bytes from 192.168.4.61: icmp_seq=2 ttl=64 time=0.314 ms
```

### 取消协议
```
[root@web01 ~]# firewall-cmd --remove-protocol=icmp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```

***


# firewalld富规则
>firewalld中的富规则表示更细致、更详细的防火墙策略配置，它可以针对系统服务、端口号、源地址和目标地址等诸多信息进行更有针对性的策略配置, 优先级在所有的防火墙策略中也是最高的。

1.富规则帮助手册
```
man firewall-cmd
man firewalld.richlanguage
           rule
             [source]
             [destination]
             service|port|protocol|icmp-block|masquerade|forward-port
             [log]
             [audit]
             [accept|reject|drop]

rule [family="ipv4|ipv6"]
source address="address[/mask]" [invert="True"]
destination address="address[/mask]" invert="True"
service name="service name"
port port="port value" protocol="tcp|udp"
protocol value="protocol value"
forward-port port="port value" protocol="tcp|udp" to-port="port value" to-addr="address"
log [prefix="prefix text"] [level="log level"] [limit value="rate/duration"]
accept | reject [type="reject type"] | drop
```
区里的富规则按先后顺序匹配，按先匹配到的规则生效。
```
--add-rich-rule='<RULE>'    //在指定的区添加一条富规则
--remove-rich-rule='<RULE>' //在指定的区删除一条富规则
--query-rich-rule='<RULE>'  //找到规则返回0 ，找不到返回1
--list-rich-rules       //列出指定区里的所有富规则
--list-all 和 --list-all-zones 也能列出存在的富规则
```

## 1、允许指定ip的所有流量

>firewall-cmd --add-rich-rule="rule family="ipv4" source address="<ip>" accept"

例：

允许来自192.168.4.62的所有流量。注意由于之前默认区域设置为drop区域，所有在这里需要指定区域
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --add-rich-rule="rule family="ipv4" source address="192.168.4.62" accept"
success
[root@web01 ~]# firewall-cmd --reload
success
```
查看富规则

```
[root@web01 ~]# firewall-cmd --list-rich
rule family="ipv4" source address="192.168.4.62" accept
```
测试
```
[root@web02 ~]# ping 192.168.4.61
PING 192.168.4.61 (192.168.4.61) 56(84) bytes of data.
64 bytes from 192.168.4.61: icmp_seq=1 ttl=64 time=0.797 ms

[root@web02 ~]# curl -I 192.168.4.61
HTTP/1.1 200 OK
-----------------------------------------
[root@web03 ~]# ping 192.168.4.61
PING 192.168.4.61 (192.168.4.61) 56(84) bytes of data.


^C
--- 192.168.4.61 ping statistics ---
2 packets transmitted, 0 received, 100% packet loss, time 1000ms

[root@web03 ~]# curl -I -s 192.168.4.61

#以上可见web02所有流量都可以访问，web02都不可访问，而且friewalld也不需要单独开启对应的服务和端口，如下

[root@web01 ~]# firewall-cmd --list-all
drop (active)
  target: DROP
  icmp-block-inversion: no
  interfaces: eth0
  sources: 
  services: 
  ports: 22/tcp
  protocols: 
  masquerade: no
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules: 
	rule family="ipv4" source address="192.168.4.62" accept
```

删除富规则
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --remove-rich-rule="rule family="ipv4" source address="192.168.4.62" accept"
success
[root@web01 ~]# firewall-cmd --reload
success
```

## 2、白名单操作

添加指定ip的主机web02到白名单
```
[root@web01 ~]# firewall-cmd --add-source=192.168.4.62 --permanent  --zone=trusted 
success
[root@web01 ~]# firewall-cmd --reload
success

查看白名单区域指定的soucrce

[root@web01 ~]# firewall-cmd --list-sources --zone=trusted 
192.168.4.62
```
白名单效果与同开放所有流量一致

删除指定ip的主机web02到白名单
```
[root@web01 ~]# firewall-cmd --remove-source=192.168.4.62 --permanent  --zone=trusted 
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-sources --zone=trusted 

```

***





## 3、允许指定ip的指定协议

>firewall-cmd --add-rich-rule="rule family="ipv4" source address="<ip>" protocol value="<protocol>" accept"

例：

#允许192.168.4.62主机的icmp协议，即允许192.168.4.62主机ping

```
[root@web01 ~]# firewall-cmd --permanent --add-rich-rule="rule family="ipv4" source address="192.168.4.62" protocol value="icmp" accept"
success
[root@web01 ~]# firewall-cmd --reload
success

查看
[root@web01 ~]# firewall-cmd --list-rich
rule family="ipv4" source address="192.168.4.62" protocol value="icmp" accept
```

测试
```
[root@web02 ~]# ping 192.168.4.61
PING 192.168.4.61 (192.168.4.61) 56(84) bytes of data.
64 bytes from 192.168.4.61: icmp_seq=1 ttl=64 time=0.947 ms

[root@web03 ~]# ping 192.168.4.61
PING 192.168.4.61 (192.168.4.61) 56(84) bytes of data.
^C
--- 192.168.4.61 ping statistics ---
```

删除
```
[root@web01 ~]# firewall-cmd --permanent --remove-rich-rule="rule family="ipv4" source address="192.168.4.62" protocol value="icmp" accept"
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-rich

```

***

## 4、允许指定ip访问指定服务

>firewall-cmd --add-rich-rule="rule family="ipv4" source address="<ip>" service name="<service name>" accept"

例：

#允许192.168.4.62主机访问ssh服务
```
[root@web01 ~]# firewall-cmd --permanent --add-rich-rule="rule family="ipv4" source address="192.168.4.62" service name="ssh" accept"
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-rich
rule family="ipv4" source address="192.168.4.62" service name="ssh" accept
```

之前默认开启了ssh，需要关闭
```
[root@web01 ~]# firewall-cmd --remove-port=22/tcp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
```

测试
```
web02测试登录
[root@web02 ~]# ssh 192.168.4.61
The authenticity of host '192.168.4.61 (192.168.4.61)' can't be established.
ECDSA key fingerprint is SHA256:GYtp4W43k6E/1PUlY9PGAT6HR+oI6j4E4HJF19ZuCHU.
ECDSA key fingerprint is MD5:3f:b3:8b:8e:21:38:6f:51:ba:f4:67:ca:2a:bc:e1:34.
Are you sure you want to continue connecting (yes/no)? yes
Warning: Permanently added '192.168.4.61' (ECDSA) to the list of known hosts.
root@192.168.4.61's password: 
Last login: Fri Dec 13 15:00:29 2019 from 192.168.4.11
[root@web01 ~]# 

web03测试登录
[root@web03 ~]# ssh 192.168.4.61

卡住

```

删除
```
[root@web01 ~]# firewall-cmd --permanent --remove-rich-rule="rule family="ipv4" source address="192.168.4.62" service name="ssh" accept"
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-rich


```
***




## 5、允许指定ip访问指定端口

>firewall-cmd --add-rich-rule="rule family="ipv4" source address="<ip>" port protocol="<port protocol>" port="<port>" accept"

例：

#允许192.168.4.62主机访问22端口
```
[root@web01 ~]# firewall-cmd --permanent --add-rich-rule="rule family="ipv4" source address="192.168.4.62" port protocol="tcp" port="22" accept" 
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-rich
rule family="ipv4" source address="192.168.4.62" port port="22" protocol="tcp" accept
```
测试同上

删除
```
[root@web01 ~]# firewall-cmd --permanent --remove-rich-rule="rule family="ipv4" source address="192.168.4.62" port protocol="tcp" port="22" accept" 
success
[root@web01 ~]# firewall-cmd --reload
success
```

## 6、将指定ip改为网段

以上的富规则实验各个命令都支持 source address 设置为网段，即这个网段的ip都是适配这个规则：

例如：

允许192.168.4.0/24网段的主机访问22端口 
```
[root@web01 ~]# firewall-cmd --zone=drop --add-rich-rule="rule family="ipv4" source address="192.168.4.0/24" port protocol="tcp" port="22" accept"
```
## 7、禁止指定ip

以上各个命令中，将 accept 设置为 reject表示拒绝，设置为 drop表示直接丢弃（会返回timeout连接超时）

### 7.1、禁止网段访问指定端口

禁止192.168.2.0/24网段的主机访问22端口 

```
[root@web01 ~]# firewall-cmd --zone=drop --add-rich-rule="rule family="ipv4" source address="192.168.4.0/24" port protocol="tcp" port="22" reject"

测试
[root@web02 ~]# ssh 192.168.4.61
ssh: connect to host 192.168.4.61 port 22: Connection refused

开放22再测试
[root@web01 ~]# firewall-cmd --add-port=22/tcp --permanent 
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --zone=drop --add-rich-rule="rule family="ipv4" source address="192.168.4.0/24" port protocol="tcp" port="22" drop"
success

测试
[root@web02 ~]# ssh 192.168.4.61
```

### 7.2禁止单个ip访问指定端口
```
[root@web01 ~]# firewall-cmd --zone=drop --add-rich-rule="rule family="ipv4" source address="192.168.4.62" port protocol="tcp" port="22" drop"
success
```

### 7.3、禁止网段访问所有服务
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --add-rich-rule='rule family=ipv4 source address="192.168.4.0/24" drop'
```
### 7.4、禁止单个ip访问所有服务
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --add-rich-rule='rule family=ipv4 source address="192.168.4.62/32" drop'
success
[root@web01 ~]# firewall-cmd --reload
success
```

***

# 防火墙端口转发策略
端口转发是指传统的目标地址映射，实现外网访问内网资源

流量转发命令格式为:

>firewall-cmd –permanent –zone=<区域> –add-forward-port=port=<源端口号>:proto=<协议>:toport=<目标端口号>:toaddr=<目标IP地址>

## 1.开启IP伪装
开启防火墙伪装：开启后才能转发端口
```
[root@web01 ~]# firewall-cmd --add-masquerade --permanent
success
[root@web01 ~]# firewall-cmd --reload
success

```
开启后状态为yes

![image.png](https://img.hacpai.com/file/2019/12/image-dda21e65.png)


## 2.转发本机666端口的流量至web02的22端口
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --add-forward-port=port=666:proto=tcp:toport=22:toaddr=192.168.4.62
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-all
drop (active)
  target: DROP
  icmp-block-inversion: no
  interfaces: eth0
  sources: 
  services: 
  ports: 22/tcp
  protocols: 
  masquerade: yes
  forward-ports: port=666:proto=tcp:toport=22:toaddr=192.168.4.62
  source-ports: 
  icmp-blocks: 
  rich rules:
```

测试-web03上测试登录
```
[root@web03 ~]# ssh -p 666 192.168.4.61
root@192.168.4.61's password: 
Last login: Fri Dec 13 16:36:46 2019 from 192.168.4.61
[root@web02 ~]# 
```

移除本机转发的666端口策略
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --remove-forward-port=port=666:proto=tcp:toport=22:toaddr=192.168.4.62
success
[root@web01 ~]# firewall-cmd --reload
success
```
***

## 富规则中的转发配置

将远程192.168.4.63主机请求firewalld的666端口，转发至后端主机192.168.4.62的22端口
```
[root@web01 ~]# firewall-cmd --permanent --zone=drop --add-rich-rule='rule family=ipv4 source address=192.168.4.63/32 forward-port port=666 protocol=tcp to-port=22 to-addr=192.168.4.62'
success
[root@web01 ~]# firewall-cmd --reload
success
[root@web01 ~]# firewall-cmd --list-all
drop (active)
  target: DROP
  icmp-block-inversion: no
  interfaces: eth0
  sources: 
  services: 
  ports: 22/tcp
  protocols: 
  masquerade: yes
  forward-ports: 
  source-ports: 
  icmp-blocks: 
  rich rules: 
	rule family="ipv4" source address="192.168.4.63/32" forward-port port="666" protocol="tcp" to-port="22" to-addr="192.168.4.62"

```

测试
```
[root@web03 ~]# ssh -p 666 192.168.4.61
root@192.168.4.61's password: 
Last login: Fri Dec 13 16:37:05 2019 from 192.168.4.61
```

***
# 防火墙开启内部上网

环境：\
提前在web01和web02中添加块网卡
```
firewalld  192.168.4.61 172.17.4.61
web02                   172.17.4.62
```

web01-eth1配置
```
[root@web01 ~]# cat /etc/sysconfig/network-scripts/ifcfg-eth1
TYPE=Ethernet
BOOTPROTO=none
NAME=eth1
DEVICE=eth1
ONBOOT=yes
IPADDR=172.17.4.61
NETMASK=255.255.255.0
```
web02-eth1配置
```
[root@web02 ~]# cat /etc/sysconfig/network-scripts/ifcfg-eth1
TYPE=Ethernet
BOOTPROTO=none
NAME=eth1
DEVICE=eth1
ONBOOT=yes
IPADDR=172.17.4.63
NETMASK=255.255.255.0
```


需求：
web02通过防火墙上网
在指定的带有公网IP的实例上操作，启动NAT网关的SNAT源地址转换功能。

1.firewalld防火墙开启ip伪装, 实现地址转换

#永久添加源地址转换功能,开启伪装
```
[root@m01 ~]# firewall-cmd --add-masquerade --permanent
[root@m01 ~]# firewall-cmd --reload
```
2.客户端配置共享上网
```
关闭eth0网卡，让其不能上网
[root@web01 ~]# systemctl stop network 
[root@web01 ~]# systemctl start NetworkManager
[root@web01 ~]# nmcli connection down eth0



#1.修改网关指向firewalld
[root@web02 ~]# cat /etc/sysconfig/network-scripts/ifcfg-eth1
GATEWAY=172.16.1.81
DNS1=223.5.5.5
DNS2=223.6.6.6

#2.重启网络
[root@web02 ~]# nmcli connection reload
[root@web02 ~]# nmcli connection down eth1 && nmcli connection up eth1

#3.检查网络配置是否生效
检查DNS
[root@web02 ~]# cat /etc/resolv.conf
nameserver 223.5.5.5
nameserver 223.6.6.6

#4.设置路由
[root@web01 ~]# route add default gw 172.17.4.61

检查网关
[root@web02 ~]# route -n
Kernel IP routing table
Destination     Gateway         Genmask         Flags Metric Ref    Use Iface
0.0.0.0         172.17.4.61     0.0.0.0         UG    100    0        0 eth1
172.16.1.0      0.0.0.0         255.255.255.0   U     100    0        0 eth1

#5.测试网络
[root@web02 ~]# ping baidu.com
PING baidu.com (123.125.115.110) 56(84) bytes of data.
64 bytes from 123.125.115.110 (123.125.115.110): icmp_seq=1 ttl=127 time=9.08 ms
```

***
# Firewalld配置备份
```
[root@web01 ~]# cd /etc/
[root@web01 etc]# tar zcf firewalld.tar.gz firewalld/
[root@web01 etc]# ls firewalld.tar.gz 
firewalld.tar.gz
```

