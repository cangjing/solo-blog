title: Linux基础之打包压缩
date: '2019-12-08 17:56:35'
updated: '2019-12-08 17:56:35'
tags: [运维基础]
permalink: /articles/2019/12/08/1575798995205.html
---

# 链接文件与tar打包
## Linux系统链接文件
### 软链接
>Linux里的软链接文件类似于Windows系统中的 “快捷键方式”里面具体存放的是源文件的路径，并指向源文件实体，因此通过访问这个“快捷方式”可迅速访问到源文件。软链接文件类型是l。 \
我们只需要执行命令 ln -s 源文件 软链接文件 完成软链接创建。 \
注意：软链接和源文件是不同类型的文件，所以inode也不同。

- [ ] //文件软链接示例
```
touch /root/file
ln -s /root/file /tmp/file_bak
ll /tmp/file_bak  //root下file链接到/tmp下并重命名为file_bak
```

- [ ] //目录软链接示例
```
mkdir /soft/nginx1.1 -p
ln -s /soft/nginx1.1/ /soft/nginx
ll /soft/nginx   //查看链接指向
```
- [ ] 生产软链接作用

>1、软件升级 \
2、企业代码发布 \
3、不方便目录移动

**注意**：
>软连接要使用绝对路径\
软链接既可以对文件也可以对目录
***
### 硬链接
>Linux文件系统中,多个文件名指向同一个索引节点(Inode)是正常且允许的（文件的多个有效的入口）,这种情况的文件称为硬链接。通过执行 ln 源文件 硬链接文件 给文件设置硬链接,来防止重要文件被误删。 \
**注意**：目录不能创建硬链接，硬链接文件可以用rm命令删除

### 软硬链接区别
Linux下软链接和硬链接的区别：

>1)ln命令创建硬链接，ln -s命令创建软链接。 \
2)目录不能创建硬链接，并且硬链接不可以跨越分区系统。 \
3)目录软链接特别常用,并且软链接支持跨越分区系统。 \
4)硬链接文件与源文件的inode相同，软链接文件与源文件inode不同。 \
5)删除软链接文件，对源文件及硬链接文件无任何影响。 \
6)删除文件的硬链接文件，对源文件及链接文件无任何影响。 \
7)删除链接文件的源文件，对硬链接无影响，会导致软链接失效。 \
8)删除源文件及其硬链接文件，整个文件会被真正的删除。

*** 
# 压缩包格式
- [ ] windows
>	rar\
	zip
- [ ] Linux
>	zip\
	tar.gz\
	tar.bz2\
	tar.xz
	
- [ ] 压缩的好处主要有：

>节省磁盘空间占用率 \
节省网络传输带宽消耗 \
网络传输更加快捷

- [ ] Linux系统常见的后缀名所对应的压缩工具

>.gz  gzip   //压缩工具压缩的文件 \
.bz2 bzip2 //压缩工具压缩的文件 \
.tar tar   //tar没有压缩功能，只是把一个目录合并成一个文件 \
.tar.gz    //先使用tar打包，然后使用gzip压缩归档 \
.tar.bz2   //先使用tar打包，然后使用bzip压缩归档\
.tar.xz    //先使用tar打包，然后使用xz压缩归档

**注意**: 
>1.Linux下常用压缩文件以.tar.gz结尾. \
2.Linux下压缩文件必须带后缀.

## TAR归档工具
>tar是linux下最常用的压缩与解压缩, 支持文件和目录的压缩\
原始含义是归档，不带压缩功能

- [ ] 语法：tar [-zjxcvfpP] filename 
- c 创建新的归档文件
- x 对归档文件解包
- t 列出归档文件里的文件列表
- v 输出命令的归档或解包的过程
- f 指定包文件名，多参数f写最后
- C 指定解压目录位置
- z 使用gzip压缩归档后的文件(.tar.gz)
- j 使用bzip2压缩归档后的文件(.tar.bz2)
- J 使用xz压缩归档后的文件(tar.xz)
- X 排除多个文件(写入需要排除的文件名称)
- p 创建压缩归档文件时，保留源文件的权限
- h 打包软链接
- --hard-dereference 打包硬链接
- --exclude 在打包的时候写入需要排除文件或目录

- [ ] 按照选项的行为分为四类
```
.tar    .tar.gz      .tar.bz2      tar.xz
cf        czf 		   cjf           cJf
tf	      tzf		   tjf           tJf
xf        xzf          xjf           xJf
```
## //常用打包与压缩组合
```
xf   自动选择解压模式
tf   查看所有压缩包内容
```
```
- .tar
解包：tar xvf FileName.tar
打包：tar cvf FileName.tar DirName
注：tar是打包，不是压缩！
\---------------------------------------------
- .gz
解压1：gunzip FileName.gz
解压2：gzip -d FileName.gz
压缩：gzip FileName
.tar.gz 和 .tgz
解压：tar zxvf FileName.tar.gz
压缩：tar zcvf FileName.tar.gz DirName
\---------------------------------------------
- .bz2
解压1：bzip2 -d FileName.bz2
解压2：bunzip2 FileName.bz2
压缩： bzip2 -z FileName
.tar.bz2
解压：tar jxvf FileName.tar.bz2
压缩：tar jcvf FileName.tar.bz2 DirName
\---------------------------------------------
- .bz
解压1：bzip2 -d FileName.bz
解压2：bunzip2 FileName.bz
压缩：未知
.tar.bz
解压：tar jxvf FileName.tar.bz
压缩：未知
\---------------------------------------------
- .Z
解压：uncompress FileName.Z
压缩：compress FileName
.tar.Z
解压：tar Zxvf FileName.tar.Z
压缩：tar Zcvf FileName.tar.Z DirName
\---------------------------------------------
- .zip
解压：unzip FileName.zip
压缩：zip FileName.zip DirName
\---------------------------------------------
- .rar
解压：rar x FileName.rar
压缩：rar a FileName.rar DirNam
```


- [ ] 首先，安装gzip bzip2 xz软件包
```
[root@oldboyedu ~]# yum install -y gzip bzip2 xz
[root@oldboyedu ~]# touch oldboy{1..10}.txt
[root@oldboyedu ~]# tar cf oldboy.tar oldboy?.txt
[root@oldboyedu ~]# tar czf oldboy.tar.gz oldboy?.txt
[root@oldboyedu ~]# tar cjf oldboy.tar.bz2 oldboy?.txt
[root@oldboyedu ~]# tar cJf oldboy.tar.xz oldboy?.txt
```
## 查看打包后的包类型

>[root@oldboyedu ~]# file oldboy.tar\
oldboy.tar: POSIX ==tar== archive (GNU)\
[root@oldboyedu ~]# file oldboy.tar.gz\
oldboy.tar.gz: ==gzip== compressed data, from Unix, last modified: Fri Aug 10 20:04:03 2018\
[root@oldboyedu ~]# file oldboy.tar.bz2\
oldboy.tar.bz2: ==bzip2== compressed data, block size = 900k\
[root@oldboyedu ~]# file oldboy.tar.xz\
oldboy.tar.xz: ==XZ== compressed data

- [ ] 解压到制定目录 -C
```
[root@oldboyedu ~]# tar xf oldboy.tar.xz -C /tmp/
```
## 排除
-  [ ] 创建压缩文件，排除单个文件
```
[root@oldboyedu ~]# tar czf oldboy1.tar.gz --exclude=oldboy5.txt oldboy*.txt
```

- [ ] 创建压缩文件，排除多个文件，需要建立一个文件列表，将需要排除的所有文件的路径，以行为单位写入该文件，创建压缩归档时使用"X"选项
```
[root@oldboyedu ~]# cat exclude.list 
oldboy2.txt
oldboy4.txt
oldboy6.txt
[root@oldboyedu ~]# tar czfX oldboy2.tar.gz exclude.list oldboy*.txt
```
