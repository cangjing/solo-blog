title: Lnmp环境搭建zabbix4.0
date: '2019-12-09 15:49:19'
updated: '2019-12-09 15:55:51'
tags: [监控]
permalink: /articles/2019/12/09/1575877759555.html
---

# Lnmp环境搭建zabbix4.0

## 第1章 最简单的安装方式

1.配置Zabbix仓库
```
rpm -ivh https://mirrors.aliyun.com/zabbix/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
rpm -ivh https://mirrors.tuna.tsinghua.edu.cn/zabbix/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
```
2.安装Zabbix程序包，以及MySQL、Zabbix-agent
```
[root@zabbix-server ~]# yum install -y zabbix-server-mysql zabbix-web-mysql zabbix-agent mariadb-server

zabbix-server-mysql #zabbix服务器包
zabbix-web-mysql    #zabbix前端包
zabbix-agent        #zabbix代理包
mariadb-server      #mysql
```
3.创建初始数据库
```
#1.启动mariadb
[root@zabbix-server ~]# systemctl start mariadb
[root@zabbix-server ~]# systemctl enable mariadb

#2.创建数据库并授权
MariaDB [(none)]> create database zabbix character set utf8 collate utf8_bin;
Query OK, 1 row affected (0.00 sec)

MariaDB [(none)]> grant all privileges on zabbix.* to zabbix@localhost identified by 'zabbix';
Query OK, 0 rows affected (0.00 sec)
```
4.导入初始架构和数据。系统将提示你输入新创建的密码。
```
zcat /usr/share/doc/zabbix-server-mysql-3.4.14/create.sql.gz | mysql -uzabbix -pzabbix zabbix
```

5.编辑/etc/zabbix/zabbix_server.conf文件，修改数据库配置(DBPassword=zabbix)
```
[root@zabbix ~]# cat /etc/zabbix/zabbix_server.conf  | egrep -v '^#|^$'
LogFile=/var/log/zabbix/zabbix_server.log
LogFileSize=0
PidFile=/var/run/zabbix/zabbix_server.pid
SocketDir=/var/run/zabbix
DBHost=localhost
DBName=zabbix
DBUser=zabbix
DBPassword=zabbix
SNMPTrapperFile=/var/log/snmptrap/snmptrap.log
Timeout=4
AlertScriptsPath=/usr/lib/zabbix/alertscripts
ExternalScripts=/usr/lib/zabbix/externalscripts
LogSlowQueries=3000
```
6.修改apache的配置文件，改时区
```
vim /etc/httpd/conf.d/zabbix.conf
#取消注释，设置正确的时区
php_value date.timezone Asia/Shanghai
```
7.启动Zabbix服务器和apache
```
启动Zabbix服务器和apache并使其在系统引导时启动
[root@zabbix-server ~]# systemctl start zabbix-server httpd
[root@zabbix-server ~]# systemctl enable zabbix-server httpd
```

8.访问zabbix-web
```
http://10.0.0.71/zabbix
```
***
## 适合生产的环境搭建
### 第2章 搭建LNMP环境
#### 2.1 安装Nginx1.14
```
[root@promote~]#wget http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
[root@promote ~]# rpm -ivh nginx-release-centos-7-0.el7.ngx.noarch.rpm    #安装nginx官方源
[root@promote ~]# yum install nginx -y
[root@promote ~]# systemctl start nginx
[root@promote ~]# systemctl enable nginx
[root@promote ~]# netstat -ntap | grep 80
tcp        0      0 0.0.0.0:80              0.0.0.0:*               LISTEN      3024/nginx: master  
```

#### 2.2 MySQL5.6.40二进制安装：
```
1）下载并解压
下载二进制包
http://mirrors.sohu.com/mysql/MySQL-5.6/mysql-5.6.40-linux-glibc2.12-x86_64.tar.gz

解压二进制包
[root@db01 ~]# tar xf mysql-5.6.40-linux-glibc2.12-x86_64.tar.gz
```
2）创建安装目录并设置软连接
```
创建安装目录
[root@db01 ~]# mkdir /data/app

移动MySQL二进制包到安装目录并改名
[root@db01 ~]# mv mysql-5.6.40-linux-glibc2.12-x86_64 /data/app/mysql-5.6.40

做软链接
[root@db01 ~]# ln -s /data/app/mysql-5.6.40 /data/app/mysql
```
3）拷贝配置文件
```
进入脚本及配置文件目录
[root@db01 ~]# cd /data/app/mysql/support-files

拷贝配置文件
[root@db01 support-files]# cp my-default.cnf /etc/my.cnf

拷贝启动脚本
[root@db01 support-files]# cp mysql.server /etc/init.d/mysqld
```
4）创建用户并授权
```
[root@db01]# useradd -M -s /sbin/nologin mysql
[root@db01]# chown -R mysql.mysql /data/mysql*
```
5）初始化
```
进入初始化目录
[root@db01 support-files]#  cd /data/app/mysql/scripts

初始化
[root@db03 scripts]# ./mysql_install_db --user=mysql --basedir=/data/app/mysql --datadir=/data/app/mysql/data
--user 指定mysql用户
--basedir 指定mysql安装目录
--datadir 指定mysql数据目录
```
6） 修改配置文件
```
修改启动脚本及程序文件路径为/application
[root@db01 mysql]# sed -i 's#/usr/local#/data#g' /etc/init.d/mysqld /data/app/mysql/bin/mysqld_safe
```
7）设置环境变量
```
添加环境变量
[root@db01 mysql]# vim /etc/profile.d/mysql.sh
export PATH="/data/app/mysql/bin:$PATH"

加载环境变量
[root@db01 mysql]# source /etc/profile
```
8）启动
```
启动mysqld
[root@db01 mysql]# /etc/init.d/mysqld start
```

9) 创建初始数据库
```
#1.启动mysql
[root@zabbix-server ~]# systemctl start mariadb
[root@zabbix-server ~]# systemctl enable mariadb

#2.创建zabbix数据库并授权
Mysql> create database zabbix character set utf8 collate utf8_bin;
Query OK, 1 row affected (0.00 sec)

Mysql grant all privileges on zabbix.* to zabbix@localhost identified by 'zabbix';
Query OK, 0 rows affected (0.00 sec)
```
***
#### 2.3 安装PHP7.2

2.3.1.下载与安装
```
[root@promote~]#rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
[root@promote ~]# rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm    #下载PHPyum源
[root@promote ~]# yum install php72w php72w-devel php72w-fpm php72w-gd php72w-mbstring php72w-mysql -y    #安装PHP相关服务
[root@promote ~]# php -v     #查看版本
PHP 7.2.10 (cli) (built: Sep 15 2018 07:10:58) ( NTS )
Copyright (c) 1997-2018 The PHP Group
Zend Engine v3.2.0, Copyright (c) 1998-2018 Zend Technologies
```
2.3.2配置nginx支持PHP：
```
[root@promote ~]# vim /etc/php-fpm.d/www.conf
8 user = nginx     #将Apache改为nginx
10 group = nginx   #将Apache改为nginx
```
2.3.3配置PHP：
```
[root@promote ~]# vim /etc/php.ini
359 expose_php = Off    #隐藏PHP版本
368 max_execution_time = 300    #监控执行时间
378 max_input_time = 300    #接收数据等待时间
389 memory_limit = 128M    #每个脚本占用内存
656 post_max_size = 16M    #POST数据大小
799 upload_max_filesize = 2M    #下载文件大小
800 always_populate_raw_post_data = -1    #可以用$HTTP_RAW_POST_DATA接收post raw data
date.timezone = Asia/Shanghai    #将时区设为上海时区
```

#### 2.4 安装zabbix
2.4.1 1.配置Zabbix仓库
```
rpm -ivh https://mirrors.aliyun.com/zabbix/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
或
rpm -ivh https://mirrors.tuna.tsinghua.edu.cn/zabbix/zabbix/3.4/rhel/7/x86_64/zabbix-release-3.4-2.el7.noarch.rpm
```
2.4.2 2.安装Zabbix程序包， Zabbix-agent
```
[root@zabbix-server ~]# yum install -y zabbix-server-mysql zabbix-web-mysql zabbix-agent
zabbix-server-mysql #zabbix服务器包
zabbix-web-mysql    #zabbix前端包
zabbix-agent        #zabbix代理包
```
2.4.3 3.导入初始架构和数据。
```
zcat /usr/share/doc/zabbix-server-mysql-3.4.14/create.sql.gz | mysql -uzabbix -pzabbix zabbix
```
2.4.4 4.编辑/etc/zabbix/zabbix_server.conf文件，修改数据库配置(DBPassword=zabbix)
```
[root@zabbix ~]# cat /etc/zabbix/zabbix_server.conf  | egrep -v '^#|^$'
LogFile=/var/log/zabbix/zabbix_server.log
LogFileSize=0
PidFile=/var/run/zabbix/zabbix_server.pid
SocketDir=/var/run/zabbix
DBHost=localhost
DBName=zabbix
DBUser=zabbix
DBPassword=zabbix
SNMPTrapperFile=/var/log/snmptrap/snmptrap.log
Timeout=4
AlertScriptsPath=/usr/lib/zabbix/alertscripts
ExternalScripts=/usr/lib/zabbix/externalscripts
LogSlowQueries=3000
```

2.4.5 拷贝zabbix站点目录并赋予文件权限：
```
[root@promote ~]# cp -r /usr/share/zabbix/ /usr/share/nginx/html/
[root@promote ~]# chown -R zabbix.zabbix /etc/zabbix/
[root@promote ~]# chown -R zabbix.zabbix /usr/share/nginx/
[root@promote ~]# chown -R zabbix.zabbix /usr/lib/zabbix/
[root@promote ~]# chmod -R 755 /etc/zabbix/web/
[root@promote ~]# chmod -R 777 /var/lib/php/session/
```
2.4.6 配置nginx站点
```
[root@liudada zabbix-backup]# cat /etc/nginx/conf.d/zabbix.conf 
server {
        server_name _;
        listen 80;
        root /usr/share/nginx/html/zabbix;
        index index.php index.html;

        location ~ \.php$ {
                root /usr/share/nginx/html/zabbix;
                fastcgi_pass   127.0.0.1:9000;
                fastcgi_index  index.php;
                fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
                include        fastcgi_params;
        }
}
```

启动所有服务：
```
[root@promote ~]# systemctl start zabbix-server.service php-fpm nginx 
```
### 第3章 安装注意事项

#### 3.1 下载文件

浏览器直接访问ip

![image.png](https://img.hacpai.com/file/2019/12/image-aea73c59.png)


出现这个请下载亲自上传到服务器，然后在刷新就好了！


#### 3.2 登录信息

登录

使用账户密码登录zabbix，默认账号密码为‘Admin’和‘zabbix’

![image.png](https://img.hacpai.com/file/2019/12/image-ac05ab12.png)


到此安装完毕
