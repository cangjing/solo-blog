title: VeryNginx搭建篇
date: '2019-12-09 16:01:10'
updated: '2019-12-09 16:01:10'
tags: [安全]
permalink: /articles/2019/12/09/1575878470272.html
---

# VeryNginx安装说明
VeryNginx 基于 OpenResty[^openresty]，所以安装 VeryNginx 需要先安装好 OpenResty。不过并不用担心安装过程中可能的麻烦，VeryNginx 自身提供了脚本来进行安装工作。

## 安装 VeryNginx
克隆 VeryNginx 仓库到本地, 然后进入仓库目录，执行以下命令
```
python install.py install
```
即可一键安装 VeryNginx 和 以及依赖的 OpenResty

**软件将会分别安装在以下目录:**
```
verynginx /opt/verynginx/verynginx
openresty /opt/verynginx/openresty
```
***
# 使用自己的Nginx
VeryNginx 使用到了以下模块，自己编译 Nginx 时，需要包含以下模块才能正常使用。
```
lua-nginx-module
http_stub_status_module
http_ssl_module

ngx_lua 即为 lua-nginx-module
```
## 操作步骤

### 创建包目录
[root@liudada ~]# mkdir /app &&  cd /app/

### 安装依赖包
```
[root@liudada ~]# yum install -y gcc gcc-c++ pcre pcre-devel zlib zlib-devel openssl openssl-devel libxml2 libxml2-devel libxslt libxslt-devel gd gd-devel GeoIP GeoIP-devel
```

http_stub_status_module 和 http_ssl_module 只需要在 ./configure 时加上两行即可。lua-nginx-module稍微麻烦一点，它需要以下依赖：

>- LuaJIT 2.0 或 LuaJIT 2.1（推荐）或 Lua 5.1（5.2 目前不支持）\
ngx_devel_kit（NDK）\
ngx_lua


### 下载所需模块：
```
[root@liudada ~]# wget http://luajit.org/download/LuaJIT-2.0.5.tar.gz
[root@liudada ~]# wget https://github.com/simplresty/ngx_devel_kit/archive/v0.3.0.tar.gz
[root@liudada ~]# wget https://github.com/openresty/lua-nginx-module/archive/v0.10.13.tar.gz
[root@liudada ~]# wget http://nginx.org/download/nginx-1.16.0.tar.gz
```

查看
```
[root@liudada app]# ls
LuaJIT-2.0.5.tar.gz  nginx-1.16.0.tar.gz  v0.10.13.tar.gz  v0.3.0.tar.gz
```
一键解压
```
[root@liudada app]# for a in `ls`;do tar xf $a;done
```

### 编译LuaJIT
```
[root@liudada app]# cd LuaJIT-2.0.5/
[root@liudada LuaJIT-2.0.5]# make && make install
```

### 编译安装 Nginx

#### 编译前的版本号优化
```
[root@liudada app]#  vim nginx-1.16.0/src/core/nginx.h +13
 13 #define NGINX_VERSION      "2.3.0"
 14 #define NGINX_VER          "tengine/" NGINX_VERSION
 
[root@liudada app]# vim nginx-1.16.0/src/http/ngx_http_header_filter_module.c +49
static u_char ngx_http_server_string[] = "Server: Tengine" CRLF;

[root@liudada app]# vim nginx-1.16.0/src/http/ngx_http_special_response.c +22


"<hr><center>tengine(https://www.zzexvip.com)</center>" CRLF
"</body>" CRLF
"</html>" CRLF
;


static u_char ngx_http_error_build_tail[] =
"<hr><center>tengine</center>" CRLF
"</body>" CRLF
"</html>" CRLF
```

#### 编译安装
```
[root@liudada app]# cd ../nginx-1.16.0/

./configure --prefix=/usr/local/nginx \
--with-http_stub_status_module \
--with-http_ssl_module \
--with-http_v2_module \
--user=nginx \
--with-http_gzip_static_module \
--http-client-body-temp-path=/usr/local/nginx/client/ \
--http-proxy-temp-path=/usr/local/nginx/proxy/ \
--http-fastcgi-temp-path=/usr/local/nginx/fcgi/ \
--add-module=../ngx_devel_kit-0.3.0/ \
--add-module=../lua-nginx-module-0.10.13  \
--with-pcre-jit \
--with-pcre

[root@liudada app]# make && make install
```
***

### 添加指定库
```
//建立软链接, 不建立会出现share object错误
ln -s /usr/local/lib/libluajit-5.1.so.2 /lib64/libluajit-5.1.so.2

//4.加载lua库，加入到ld.so.conf文件
echo "/usr/local/LuaJIT/lib" >> /etc/ld.so.conf
ldconfig
```

### 创建用户
```
[root@localhost nginx-1.11.2]# /usr/local/nginx/sbin/nginx
nginx: [emerg] getpwnam("nginx") failed

没有安装nginx用户导致的无法启动
[root@localhost nginx-1.11.2]# useradd -s /sbin/nologin -M nginx
[root@localhost nginx-1.11.2]# id nginx
```

### 验证lua功能

server中添加个location
```
location /hello {
            default_type liudada/html;
            content_by_lua_block {
                ngx.say("HelloWorld")
            }
        }
```

### 重新加载nginx
```
[root@liudada conf]# ../sbin/nginx -t
[root@liudada conf]# ../sbin/nginx -s reload
```

### 验证
```
[root@liudada conf]# curl localhost/hello
HelloWorld
```
***
# 安装 VeryNginx
下载与安装 VeryNginx
```
yum install -y  git
git clone https://github.com/alexazhou/VeryNginx.git
cd VeryNginx
python install.py install verynginx
```

## 在Nginx 配置文件基础上添加了三条 Include 指令来实现功能:
```
在 http 配置块外部，加入：
include /opt/verynginx/verynginx/nginx_conf/in_external.conf;

在 http 配置块内部，加入：
include /opt/verynginx/verynginx/nginx_conf/in_http_block.conf;

在 server 配置块内部，加入：
include /opt/verynginx/verynginx/nginx_conf/in_server_block.conf;
```
以上三条指令分别放在 http 配置块外部，http 配置块内部，server 配置块内部，在修改时请保留这三条。\
如果添加了新的 Server 配置块或 http 配置块，也需要在新的块内部加入对应的 include 行


##访问：
```
ip/verynginx/index.html
默认用户名和密码都是 verynginx，登录后请务必修改
```
