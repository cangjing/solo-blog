title: VeryNginx配置篇
date: '2019-12-09 16:04:49'
updated: '2019-12-09 16:05:57'
tags: [安全]
permalink: /articles/2019/12/09/1575878688946.html
---

# 自定义行为 ( Custom Action )

![image.png](https://img.hacpai.com/file/2019/12/image-d03b4dc4.png)

## 匹配器 (Matcher)


VeryNginx 会收到各种各样的Http请求，当我们定义一条规则（Action）的时候，我们可能会需要限定，这条规则只对一部分请求起作用，Matcher 就是匹配器，用来描述哪一部分 Http 请求是规则的目标。

一个 Matcher 可以包含一个或者多个约束条件，当某个请求没有违背 Matcher 中任何一条约束时，就认为这个请求匹配上了这个Matcher。

>如果Matcher是空的，即没有包含任何条件，那么这个Matcher会匹配上所有的请求

目前支持以下几种约束：

### Client IP

客户端IP，对应Nginx变量 remote_addr

支持的匹配方式:
```
等于某个IP
不等于某个IP
```
### Host

客户访问时使用的域名，对应Nginx变量 host

支持的匹配方式:
```
等于某个字符串
不等于某个字符串
符合某个正则表达式
不符合某个正则表达式
```

### UserAgent

用户浏览器的UserAgent字段，对应Nginx变量 http_user_agent

>一些通过工具发起的请求可能会有特别的UserAgent，或者没有这个字段，也可能伪造成普通的浏览器

支持的匹配方式:
```
等于某个字符串
不等于某个字符串
符合某个正则表达式
不符合某个正则表达式
为空，即Http头中没有这个字段
```
### URI

请求路径，对应Nginx中的变量 uri ，表示访问地址中域名之后的部分

>例如访问 http://www.abc.com/test/book.html 时，uri值为 /test/book.html

支持的匹配方式:
```
等于某个字符串
不等于某个字符串
符合某个正则表达式
不符合某个正则表达式
```
### Referer

请求来源网页，对应Nginx中的变量 http_referer ，表示访问者的来源页面。

支持的匹配方式:
```
等于某个字符串
不等于某个字符串
符合某个正则表达式
不符合某个正则表达式
为空，即Http头中没有这个字段
```

### Request Args

请求参数匹配

VeryNginx可以智能的从uri字符串后面，以及请求体(body)内提取参数的值

>注：目前只支持在请求的content-type为application/x-www-form-urlencoded时，从请求体内提取参数

这个条件可以输入两个字段，name 和 value。name是可选的，如果输入name，则只把符合name条件的参数值和value作匹配；如果不输入name，就会把所有的参数值拿来和value进行匹配

支持的匹配方式:
```
等于某个字符串
不等于某个字符串
符合某个正则表达式
不符合某个正则表达式
```
***
## 行为 (Action)

### 协议锁定( Scheme Lock )

#### 功能介绍

协议锁定功能可以确保用户访问时使用正确的协议 ( Http / Https )

#### 配置说明

可以定义多条规则，每条规则包含以下参数

- Enable
- Matcher
- Scheme


#### 执行过程

**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

当Http请求使用的访问协议和规则中的 scheme 项不一致时，将自动返回一个302重定向，将浏览器重定向到正确的协议 + 当前的地址上。如果使用和规则一致的协议来访问，则不会有任何动作

**注意事项**

- 注意规则的顺序，防止一个严格的 Matcher 被排名更前的宽松 Matcher 覆盖，导致规则不起作用
- 如果服务器有向外提供Api的话，需要特别注意和Api的兼容性，通常来说Api的调用方不是真正的浏览器，很可能不支持302重定向

***
### 重定向( Redirect )

#### 功能介绍
Redirect可以将一个请求重定向到另外一个地址



#### 配置说明
可以定义多条规则，每条规则包含以下参数

- Enable
- Matcher
- RegEx
- Redirect to

#### 执行过程
**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

当 Regex 项为空时， 请求将被重定向到Redirect to 项填写的地址。 当 Regex 项不为空时，新地址由gsub算法生成:
```
new_address = gsub( uri, re,redirect_to )
```
其中 re 为规则中定义的Regex，redirect_to 为规则中定义的 Redirect to 项目

**注意事项**

- Redirect to 项可以是以下两种形式
```
1、带有协议以及域名 (http/https)://www.abc.com/test/aaa/bbb
2、不带有域名 /test/aaa/bbb
```
- 重定向时url后的查询字符串参数将会被保留
- 注意规则的顺序，防止一个严格的Matcher被排名更前的宽松Matcher覆盖，导致规则不起作用


***
### URI重写( URI Rewrite )

#### 功能介绍
URI Rewrite 可以将请求的URI进行内部改写，而用户浏览器地址栏显示的地址并不会发生变化


#### 配置说明
可以定义多条规则，每条规则包含以下参数:

- Enable
- Matcher
- RegEx
- Redirect to

#### 执行过程
**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

当 Regex 项为空时， 请求将被重定向到Redirect to 项填写的地址。 当 Regex 项不为空时，新地址由gsub算法生成:
```
new_address = gsub( uri, re,redirect_to )
```
其中 re 为规则中定义的Regex，redirect_to 为规则中定义的 Redirect to 项目

示例1 :

VeryNginx默认访问路径是 /veryngingx/dashboard/index.html, 我们想缩短到 /vn/index.html, 可以作以下配置:

>Matcher: URI ≈ ^/vn

>Regex: ^/vn/(.*)

>Redirect to: /verynginx/dashboard/$1

添加规则之后，通过 /vn/index.html 即可访问配置面板

**注意事项**
- Redirect to 项只可以是 / 开头的地址
- 重定向时url后的查询字符串参数将会被保留
- 注意规则的顺序，防止一个严格的Matcher被排名更前的宽松Matcher覆盖，导致规则不起作用

***
### 浏览器验证( Browser Verify )

#### 功能介绍
Browser Verify可以验证发起请求的客户端是否为浏览器，并拦截来自非浏览器客户端的请求


#### 配置说明
可以定义多条规则，每条规则包含以下参数:

- Enable
- Matcher
- Verify Type
- Cookie
- JavaScript

#### 执行过程
**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

当收到一个请求时，VeryNginx 会通过算法得到一个Token

- 当配置Verify Type为Cookie时:
>用户的Cookie中没有带有这个Token时，将会返回一个302重定向，将用户重定向到当前地址，并在http响应头中设置cookies。如果客户端是浏览器，将自动带上这个Token再继续访问，此时将被放行。如果客户端是其他工具，并且该工具不支持302以及http响应头中的set cookies字段，将无法继续访问

- 当配置Verify Type为JavaScript时:
>和 Type 为 Cookie 时原理类似，不同之处在于没有Token时，返回一个网页，并通过内嵌在网页中的JavaScript来设置Cookies并发起重定向。需要浏览器支持JavaScript才可以验证通过

**Token生成算法原型**
```
Token = hash( client_ip + UserAgent + key )
```
其中Key为VeryNginx第一次运行时产生的随机数

这样可以为每个用户和浏览器产生不同的Token，并且无法伪造

**注意事项**
- 注意规则的顺序，防止一个严格的Matcher被排名更前的宽松Matcher覆盖，导致规则不起作用
- 本功能可能会影响搜索引擎抓取信息，建议只针对部分页面开启，或者仅在被攻击时开启

***
### 访问频率限制( Frequency Limit )
#### 功能介绍
Frequency Limit 可以限制访问特定时间内请求的次数，超出限制时将截断并返回指定的状态码


#### 配置说明
可以定义多条规则，每条规则包含以下参数:

- Enable
- Matcher
- Time(s)
- Max Request Times
- Count Alone
- Return Code

#### 执行过程
**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

每条规则会对命中的请求进行计数，单位时间( Time ) 内最多放行指定次数( Max Request Times ) 的请求，单位时间内超过次数的请求将返还指定的状态码。

- 未设置单独统计( Count Alone )的情况下，匹配这条规则的所有请求最多为 Max Request Times 次。

- 通过设置单独统计( Count Alone )选项，可以根据 IP (或 URI)分别进行计数，即命中 Matcher 情况下，相同 IP (或 URI)单位时间内请求不超过指定次数。

#### 注意事项
无

***
### 过滤器( Filter )
#### 功能介绍
Filter可以阻止访问请求，并返回指定的状态码

#### 配置说明
可以定义多条规则，每条规则包含以下参数:

- Enable
- Matcher
- Action
- Return Code

#### 执行过程
**寻找规则**

每收到一个请求，VeryNginx将按照从上到下(序号递增)的顺序，取每一条规则的 Matcher 进行匹配测试，当找到第一个符合的Matcher时，即由这一条规则进行处理，停止后续匹配

**应用规则**

当 Action 项为 accept 时， 不进行任何动作，继续按照正常流程处理

当 Action 项为 block 时，拦截请求，并返回 Return code 项指定的状态码

**注意事项**
- 注意规则的顺序，防止一个严格的Matcher被排名更前的宽松Matcher覆盖，导致规则不起作用
***

### **自定义动作执行顺序**
Action 将会按照以下顺序来执行

- 协议锁定( Scheme Lock )
- 重定向( Redirect )
- URI重写( URI Rewrite )
- 浏览器验证( Browser Verify )
- 访问频率限制( Frequency Limit )
- 过滤器( Filter )
***

