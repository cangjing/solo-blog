title: Linux 上的命令行回收站工具
date: '2019-12-09 15:27:14'
updated: '2019-12-09 15:27:14'
tags: [运维技能]
permalink: /articles/2019/12/09/1575876434189.html
---
# Trash-Cli：Linux 上的命令行回收站工具
>作为系统运维小白的你，删过/吗？就像dba大牛没有删过库一样，但是前提没有做备份的话就要跑路了，当然啦，就算是在确保万无一失的情况下，也没有人敢担保不会造成系统误删除，想必经历过删/和干库的你已经对数据库做了备份，系统也做了镜像。或者你已经有了比这篇文章还完美的防御措施，不为啥 只为我们经历过！

![image.png](https://img.hacpai.com/file/2019/12/image-c31c1879.png)




## Trash-Cli介绍
>trash-cli是一个命令行回收站工具，并且符合 FreeDesktop.org 的垃圾trash规范。它能够存储每一个垃圾文件的名字、原始路径、删除日期和权限。
当通过文件管理器删除一个文件或目录的时候，该文件或目录将会成为垃圾trash，然后被移动到回收站中，回收站对应的目录是 ==$HOME/.local/share/Trash== 。


## 安装：
trash-cli的项目地址:https://github.com/andreafrancia/trash-cli

```
下载：
wget https://github.com/andreafrancia/trash-cli/archive/master.zip

解压: 
unzip trash-cli-master.zip
 
安装:
cd trash-cli-master
python setup.py install
```

## 使用 Trash-Cli
安装成功后我们的系统就有了以下工具:

- trash-put： 删除文件和目录（仅放入回收站中）
- trash-list ：列出被删除了的文件和目录
- trash-restore：从回收站中恢复文件或目录 trash.
- trash-rm：删除回收站中的文件
- trash-empty：清空回收站

## 替代 rm命令
在 ~/.bashrc 文件中间加入:

alias rm="trash-put"
 
完成后输入source source ~/.bashrc使修改的别名生效。

## 实验

1) 创建实验环境
```
[root@liudada ~]# mkdir -p /tmp/trash/{zhangsan,lisi}
[root@liudada ~]# ls /tmp/trash/
lisi  zhangsan
```
2) 删除zahngsan目录：在这个例子中，通过运行下面这个命令，将zhangsan，lisi 这一文件夹移动到回收站中。由于已经做好了rm别名设置，所以这里删除就直接用rm
```
[root@liudada trash]# rm -rf zhangsan lisi
```


3) 列出被删除了的文件和目录：为了查看被删除了的文件和目录，需要运行下面这个命令。之后，可以在输出中看到被删除文件和目录的详细信息，比如名字、删除日期和时间，以及文件生前所属路径。

```
[root@liudada trash]# trash-list 
2019-09-17 16:58:21 /tmp/trash/zhangsan
2019-09-17 16:58:21 /tmp/trash/lisi
```

4) 从回收站中恢复文件或目录：任何时候，都可以通过运行下面这个命令来恢复文件和目录。它将会询问你来选择你想要恢复的文件或目录。这里恢复zhangsan 目录，所以选择的是 0 。

```
[root@liudada trash]# trash-restore 
   0 2019-09-17 16:58:21 /tmp/trash/zhangsan
   1 2019-09-17 16:58:21 /tmp/trash/lisi
What file to restore [0..1]: 0

查看
[root@liudada trash]# ls /tmp/trash/
zhangsan
```



5) 从回收站中删除文件：如果你想删除回收站中的特定文件，那么可以运行下面这个命令。这里将删除 lisi 目录。

```
删除前查看回收站
[root@liudada trash]# trash-list 
2019-09-17 16:58:21 /tmp/trash/lisi

确认文件后删除
[root@liudada trash]# trash-rm lisi

再次确认
[root@liudada trash]# trash-list 
[root@liudada trash]# 
```

6)清空回收站：如果想删除回收站中的所有文件和目录，可以运行下面这个命令。

```
清空前创建几个文件
[root@liudada trash]# touch zn zc cf sb dp zz wj lz yunf dz
[root@liudada trash]# ls
cf  dp  dz  lz  sb  wj  yunf  zc  zhangsan  zn  zz

删除所有创建的文件
[root@liudada trash]# rm -rf *

查看回收站
[root@liudada trash]# trash-list 
2019-09-17 17:03:53 /tmp/trash/cf
2019-09-17 17:03:53 /tmp/trash/dp
2019-09-17 17:03:53 /tmp/trash/dz
2019-09-17 17:03:53 /tmp/trash/lz
2019-09-17 17:03:53 /tmp/trash/sb
2019-09-17 17:03:53 /tmp/trash/wj
2019-09-17 17:03:53 /tmp/trash/yunf
2019-09-17 17:03:53 /tmp/trash/zc
2019-09-17 17:03:53 /tmp/trash/zhangsan
2019-09-17 17:03:53 /tmp/trash/zn
2019-09-17 17:03:53 /tmp/trash/zz

清空回收站
[root@liudada trash]# trash-empty 

再次查看，回收站为空
[root@liudada trash]# trash-list 
```

7)删除超过 X 天的垃圾文件：或者，可以通过运行下面这个命令来删除回收站中超过 X 天的文件。在这个例子中，将删除回收站中超过 10 天的项目。
```
[root@liudada trash]# trash-empty 10
```
