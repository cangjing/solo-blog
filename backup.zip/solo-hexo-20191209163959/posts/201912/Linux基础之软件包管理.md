title: Linux基础之软件包管理
date: '2019-12-08 19:52:30'
updated: '2019-12-08 19:52:30'
tags: [运维基础]
permalink: /articles/2019/12/08/1575805950313.html
---
# Linux软件包管理

- [ ] RPM
>RPM Package Manager，前身Redhat Package Manager\
	有一个完整数据库体系，每个RPM包的所有信息都固定保存在指定的位置，利于查询
	
	
源码

	最原始代码，最新的版本，功能、bug
	
二进制
![image](http://m.qpic.cn/psb?/V113NhGX0EIAET/VPrlsbH9kz2j9LfpBAmNyWef5Wxk2WGc7VptGf9Y.9I!/b/dFMBAAAAAAAA&bo=7ASJAQAAAAADB0I!&rf=viewer_4)
## RPM包管理：

### 安装
-  [ ] 参数
```
-i: 安装
-v: 详细信息
-h: 安装进度
--nodeps 
忽略依赖关系（不建议）
--force强制覆盖安装
覆盖安装过程中，如果软件自带文件都存在，安装过程中不会将这些文件重新覆盖
preparing：准备过程
	检查软件包的依赖关系
		只要检测安装软件包中有依赖关系，且没有找到所以依赖的软件包，停止安装
	检查软件包是否已安装
		只要检测安装软件包中有一个已经安装了，就停止安装		
```
```	
[root@oldboy ~]# rpm -ivh /mnt/Packages/telnet* 
Preparing...                          ################################# [100%]Updating / installing...   
1:telnet-server-1:0.17-64.el7      ################################# [ 50%]   
2:telnet-1:0.17-64.el7             ################################# [100%]
```
### 2.查询
> rpm -q      //查看指定软件包是否安装                    ***\
rpm -qa     //查看系统中已安装的所有RPM软件包列表       *****\
rpm -qi     //查看指定软件的详细信息\
rpm -ql     //查询指定软件包所安装的目录、文件列表      ***\
rpm -qc     //查询指定软件包的配置文件\
rpm -qd     //查询指定软件包的帮助文档\
rpm -qf     //查询文件或目录属于哪个RPM软件             *****

//查询未安装的软件包信息
> rpm -qip    //查询未安装的rpm包详细信息
rpm -qlp    //查询未安装的软件包会产生哪些文件
```
[root@oldboy ~]# rpm -qf `which mount`util-linux-2.23.2-52.el7.x86_64
```
```
[root@oldboy ~]# rpm -qa vim*
vim-common-7.4.160-4.el7.x86_64
vim-filesystem-7.4.160-4.el7.x86_64
vim-enhanced-7.4.160-4.el7.x86_64
vim-minimal-7.4.160-4.el7.x86_64
[root@oldboy ~]# rpm -qa |wc -l
468
```
### 3.升级
> -U  如果老版本不存在，就全新安装，如果存在有新版本即升级
-F   老版本必须存在

### 4.卸载
> -e
需要考虑依赖关系
	
- [ ] 安装 .rpm 软件包时，-i、-U、-F选项有何区别？
> -i 安装软件包，必须没有之前版本，如果有之前版本--force-U 升级安装软件包，之前版本可有可无-F 刷新安装软件包，必须有之前版本
					
***								
##  ==YUM仓库==
> yum
	yellowdog update modify
	yum是基于RPM包管理, 能够自动解决依赖关系, 极大的方便rpm包的安装升级

### 1.本地仓库________
- [ ] 1）挂载镜像
```
[root@luqyf ~]# mount /dev/cdrom /mnt
```
- [ ] 2)备份原有仓库
```
[root@luqyf ~]# mkdir /etc/yum.repos.d/backup[root@luqyf ~]# cd /etc/yum.repos.d/[root@luqyf ~]# cp *.repo backup/[root@luqyf ~]# rm -f *.repo
```
- [ ] 3）创建新仓库文件，并加入如下内容：
```
使用yum-config-manager命令添加本地仓库（方法一）
[root@luqyf ~]# yum-config-manager --add-repo="file:///mnt"
手动添加repo配置文件（方法二）
[root@luqyf ~]# vim /etc/yum.repos.d/cdrom.repo
[local]name=this is local cdrom.repobaseurl=file:///mntenabled=1gpgcheck=0
[  ]			#仓库名称
name		#仓库描述信息
baseurl		#yum源url地址，可以是file:///  ftp:// http://
enabled		#是否激活该yum源（0代表就禁用，1代表激活，默认为激活）
gpgcheck	#安装软件时是否检查签名（0代表禁用，1代表激活）
```

```
[c7-media]
name=CentOS-$releasever - Media
baseurl=file:///mnt/cdrom
gpgcheck=0
enabled=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
```
- [ ] 4）刷新repos生成缓存
```
yum clean all
yum makecache

缺点：1.软件版本较低 2.软件不全 3.光驱读速慢	
临时使用
```
***

### 2.网络仓库
- [ ] 2阿里官方源
```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repoyum makecache
```
- [ ] 阿里扩展源
```
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
```
- [ ] 3.nginx官方库
```
cat >nginx.repo<<EOF 
[nginx]
name=nginx repo
baseurl=http://nginx.org/packages/centos/7/$basearch/
gpgcheck=0
enabled=1
EOF
```
- [ ] 4.mysql官方库
创建mysql官方库
```
yum install -y https://repo.mysql.com//mysql80-community-release-el7-1.noarch.rpm
```
- [ ] 5.zabbix官方库
创建zabbix官方库
```
rpm -i https://repo.zabbix.com/zabbix/3.4/rhel/6/x86_64/zabbix-release-3.4-1.el6.noarch.rpm
```
- [ ] 6.openstack官方库
创建openstack官方库
```
yum install centos-release-openstack-mitakayum install https://repos.fedorapeople.org/repos/openstack/openstack-mitaka/rdo-release-mitaka-6.noarch.rpm
```
- [ ] 7.saltstack官方库
创建国内阿里库
```
yum install https://mirrors.aliyun.com/saltstack/yum/redhat/salt-repo-latest-2.el7.noarch.rpmsed -i "s/repo.saltstack.com/mirrors.aliyun.com\/saltstack/g" /etc/yum.repos.d/salt-latest.repo
```
### 企业部署服务器的流程：
> 1.最小化安装操作系统\
2.部署网络库和官方库\
3.更新内核\
	yum update

***
## yum命令
> yum\
	list      列出每个软件包（包括未安装和已安装）     rpm -q\
	repolist  列出所有仓库名称\
	info      查看软件信息 							   rpm -qi\
	install   安装									   rpm -ivh\
	reinstall 重新安装								   rpm -ivh --force\
	remove    卸载									   rpm -e\
	search    \
	provides  *****  \
	clean all\
	makecache 创建缓存
	
- [ ] 组管理
  > grouplist\
	groupinstall\
	groupremove


***
	
## ==构建企业内网yum在线更新==：
![image](http://m.qpic.cn/psb?/V113NhGX0EIAET/50BcmLZKMAU8.hGzYl76qOuqsGbMqEpdjOqzfXxcqGY!/b/dDYBAAAAAAAA&bo=AgOgAQAAAAADB4I!&rf=viewer_4)
### 服务端
#### 1.服务端自己构建相应的yum库
> 阿里云网络yum库

- [ ]  base库
> 来自光盘（mount /dev/cdrom /mnt）


- [ ] update库
```
wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
```
- [ ] epel库
```
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
```
- [ ] nginx库
```
cat > /etc/yum.repos.d/nginx.repo<<EOF 
[nginx]
name=nginx repo
baseurl=http://nginx.org/packages/centos/7/$basearch/
gpgcheck=0
enabled=1
EOF
```
#### 2.搭建ftp
==开启yum缓存功能==
```
[root@oldboy ~]# vim /etc/yum.conf
[main] cachedir=/var/cache/yum/$basearch/$releasever 
keepcache=1
[root@oldboy ~]# yum clean all
```
- [ ] 1)安装vsftpd
```
yum install -y vsftpd
```
- [ ] 2)关闭selinux
```
//临时关闭
setenforce 0
//永久关闭
vim /etc/selinux/config
SELINUX=disabled
```
- [ ]  3)关闭防火墙
```
//临时关闭
systemctl stop firewalld
//永久关闭
systemctl disable firewalld
```
- [ ] 4)启动ftp服务
```
systemctl start vsftpd
systemctl enable vsftpd
```
- [ ] 5)创建yum仓库对应的目录
```
mkdir /var/ftp/{base,update,nginx,epel}
```
#### 3.分别构建base，update，nginx库资源
- [ ] 1)base库
```
rpm包来自光盘
mount /dev/cdrom /mnt
cp -rf /mnt/* /var/ftp/base/
```
- [ ] 2)update库
rpm包来源阿里云
```
yum clean all
yum update -y --downloadonly
find /var/cache/yum/x86_64/7 -name "*.rpm" -exec cp {} /var/ftp/update \;
```
==创建repofile==
```
#安装createrepo
yum install -y createrepo
#生成仓库信息（菜单列表）
createrepo /var/ftp/update
```
- [ ] 3）epel库

```
yum clean all && yum makecache
cp -rf /var/cache/yum/x86_64/7/eperl/*  /var/ftp/epel

//创建repofile（菜单列表）
createrepo /var/ftp/epel
```
- [ ] 4)nginx库
rpm包来源nginx官网
```
yum clean all
yum install nginx -y --downloadonly
find /var/cache/yum/x86_64/7 -name "*.rpm" -exec cp {} /var/ftp/nginx \;

//创建repofile（菜单列表）
createrepo /var/ftp/nginx
```
-------------------------------------------------------------------------------------------------------------------------------------

### 客户端：
#### 1. 关闭selinux和防火墙，
> 配置同服务端
#### 2. 配置yum库文件
rm -f /etc/yum.repos.d/*.repo

- [ ] base库:
```
cat > /etc/yum.repos.d/base.repo<<EOF 
[base]
name=base repo
baseurl=ftp://10.0.0.1/base
gpgcheck=0
enabled=1
EOF
```
- [ ] epel库：
```
cat > /etc/yum.repos.d/epel.repo<<EOF 
[update]
name=update repo
baseurl=ftp://10.0.0.1/uepel
gpgcheck=0
enabled=1
EOF
```
- [ ] update库:
```
cat > /etc/yum.repos.d/update.repo<<EOF 
[update]
name=update repo
baseurl=ftp://10.0.0.1/update
gpgcheck=0
enabled=1
EOF
```
- [ ] nginx库:
```
cat > /etc/yum.repos.d/nginx.repo<<EOF 
[nginx]
name=nginx repo
baseurl=ftp://10.0.0.1/nginx
gpgcheck=0
enabled=1
EOF
```
- [ ] 企业自动化部署：
> shell script
ansiable
saltstack

***
# 源码包安装（nginx-1.15.3）
- [ ] 1.从官网获取源码包（一般都是tar包）
```
mkdir -p /soft/src
cd /soft/src
wget http://nginx.org/download/nginx-1.15.3.tar.gz
```
- [ ] 2.解压
```
tar xf nginx-1.15.3.tar.gz
```
- [ ] 3.配置./configure(安装前的配置)
```
1)安装路径
2)功能模块
	检测依赖关系
3)生成makefile文件
```
cd nginx-1.15.3

- [ ] 4.编译make
```
根据makefile上的内容将源码编程成二进制
```
- [ ] 5.安装
make install

##精简步骤：
- [ ] 1)安装依赖环境
```
yum install gcc make prce-devel zlib-devel openssl-devel
useradd -uid 250 -s /sbin/nologin -M www
```
- [ ] 2)安装
```
./configure --prefix=/soft/nginx-1.15.3 --user=www --group=www --with-http_ssl_module && make && make install
```
***
## 异常报错：
>1.权限\
2.空格\
3.源代码

***






