title: Linux基础之find查找
date: '2019-12-08 16:44:01'
updated: '2019-12-08 16:44:01'
tags: [运维基础]
permalink: /articles/2019/12/08/1575794641796.html
---


# 文件查找：
- 在文件系统上查找符合条件的文件；
- [ ] 实现工具：locate，find
		
## locate：
>依赖于事先构建好的索引库；\
			系统自动实现（周期性任务）；\
			手动更新数据库（updatedb）；
		
- [ ] 工作特性：
>查找速度快；\
模糊查找；\
非实时查找；

yum install -y mlocate	
```
locate [OPTION]... PATTERN..
命令选项：
	-b：只匹配路径中的基名；
		path：
			basename
			dirname
	-c：统计出共有多少个符合条件的文件；
	-r：BRE
```			
注意：索引构建过程(updatedb)需要遍历整个根文件系统，极消耗资源；

***
# find：
实时查询工具，通过遍历指定起始路径下文件系统层级结构完成文件查找；
		
- [ ] 工作特性：
> 查找速度略慢；\
精确查找；\
实时查找；
			
- [ ] 用法：
find [OPTIONS] [查找起始路径] [查找条件] [处理动作]
			
- **查找起始路径**：指定具体搜索目标起始路径，默认为当前目录；
- **查找条件**：指定的查找标准，可以根据文件名、大小、类型、从属关系、权限等等进行，默认为找出指定路径下的所有问文件；
- **处理动作**：对符合查找条件做出的操作，例如删除等操作，默认为输出至标准输出；
				
## 查找条件：
表达式：选项和测试
			
测试：结果通常为布尔型（真 or 假）
			
### 根据文件名查找：
>-name：\
-iname：\
通配符* ？\
-regex：基于正则表达式模式查找文件，匹配是整个路径，而非其名；
					
### 根据文件从属关系查找：
>-user\
-group\
-uid\
-gid\
-nouser：查找没有属主的文件；\
-nogroup：查找没有属组的文件；
- [ ] 例子
```
chown oldboy file-0?
chown .oldboy file-1?
find . -user oldboy
find . -group oldboy
id oldboy
find . -uid 6002
find . -gid 6005
chown bbb.bbb file-20
userdel -r bbb
find . -nouser -ls
find . -nogroup -ls
```				
### 根据文件类型查找：
- [ ] -type TYPE：

>	f：普通文件\
	d：目录文件\
	l：符号链接文件\
	b：块设备文件\
	c：字符设备文件\
	p：管道文件\
	s：套接字文件
						
### 组合测试：
>与：-a\
或：-o\
非：-not，!\
!A -a !B = !(A -O B)\
!A -o !B = !(A -a B)
					
练习：
1、找出/tmp目录下属主为非root的所有文件；
```
find /tmp -not -user root -ls
```				
2、找出/tmp目录下文件名中不包含fastab字符串的文件；
```
find /tmp  -not -iname "*fstab*" -ls
```
3、找出/tmp目录下属主为非root，而且文件名不包含fstab字符串的文件；
```
find /tmp -not \( -user root -o -iname "*fstab*" \) -ls
or
find /tmp -not -user root -a -not -iname "*fstab*" -ls
```					
### 根据文件的大小查找：
>-size [+|-] #UNIT\
>- 常用单位：k M G\
#UNIT：(#-1,#)\
5M：(4M,5M)\
-#UNIT：(0,#-1)\
-5M: (0,4M)\
+#UNIT：(,oo)\
+5m: (5M,oo)
						
### 根据时间戳查找：
				
- [ ] atime:access time
- 文件访问时间，从CentOS/RHEL6开始，atime更改不在随着每次访问自动更改
- 更新周期：86400（秒）


- [ ] mtime:modify time
- 文件修改时间

- [ ] ctime  
- 文件属性修改时间
				
#### 以"天"为单位：
```
	-atime [+|-]#
	#：
	-#：
	find /etc -atime -7 七天内的文件
	+#：
	find /etc -atime +7 七天之前的文件
	-mtime
	-ctime
```
#### 以"分钟"为单位：
```
-amin：
-mmin：
-cmin：
for i in {01..31};do date -s  201808$i && touch file-$i;done
find . -mtime +7 -ls
find . -mtime -7 -ls
find . -mtime 7 -ls
```
				
				
### 根据权限查找：
- [ ] -perm [/|-] mode
- mode：精确权限匹配；
- /mode：任何一类用户(u,g,o)的权限中的任何一位(r,w,x)符合条件即满足；
>9位权限之间存在“或”关系；\
rwxrwxrwx

- -mode：每一类用户(u,g,o)的权限中的每一位(r,w,x)同时符合条件即满足；
>9位权限之间存在“与”关系；\
rwx rwx rwx

```		       
[root@oldboyedu test]# ls
a  b  c  d  e  f  g  h  i  j  k
[root@oldboyedu test]# 
[root@oldboyedu test]# chmod u+s a b c
[root@oldboyedu test]# chmod g+s d e f
[root@oldboyedu test]# find . -perm -4000
./a
./b
./c
[root@oldboyedu test]# find . -perm -2000
./d
./e
./f
[root@oldboyedu test]# find . -perm -6000
[root@oldboyedu test]# find . -perm /6000
./a
./b
./c
./d
./e
./f
```
### 处理动作：
>-print：输出至标准输出，默认的动作；\
-ls：类似于对查找的文件执行"ls -l"命令，输出文件的详细信息；\
-delete：删除查找到的文件；\
-fls /PATH/TO/SOMEFILE：把查找到的所有文件的长格式信息保存至指定文件中；\
-ok COMMAND {} \; ：对查找的每个文件执行由COMMAND表示的命令，每次操作都由用户进行确认；\
-exec COMMAND {} \;：对查找的每个文件执行由COMMAND表示的命令，不需确认；

```				
[root@oldboyedu ~]# find ./ -perm /002 -exec mv {} {}.danger \;
[root@oldboyedu ~]# touch {1..10}.txt
[root@oldboyedu ~]# find . -name "*.txt" -exec cp {} /tmp/ \;
[root@oldboyedu ~]# ls /tmp/
1.txt  10.txt  2.txt  3.txt  4.txt  5.txt  6.txt  7.txt  8.txt  9.txt
[root@oldboyedu ~]# find . -name "*.txt" -exec cp {} /tmp/{}.bak \;
[root@oldboyedu ~]# ls /tmp/
1.txt.bak   2.txt.bak  4.txt.bak  6.txt.bak  8.txt.bak
10.txt.bak  3.txt.bak  5.txt.bak  7.txt.bak  9.txt.bak
[root@oldboyedu ~]# find . -name "*.txt" -exec mv {} {}.bak \;
[root@oldboyedu ~]# ls
1.txt.bak   2.txt.bak  4.txt.bak  6.txt.bak  8.txt.bak
10.txt.bak  3.txt.bak  5.txt.bak  7.txt.bak  9.txt.bak
```	
**注意**：find传递查找到的文件路径至后面的命令时，是先查找出所有符合条件的文件路径，并一次性传递给后面的命令，但是有些命令不能接受过长的参数，此时命令执行会失败；另一种方式可规避此问题；\
find | xargs COMMAND
***		
- [ ] 日常练习：

1、查找/var目录下属主为root，且属组为mail的所有文件和目录；
```
[root@luqyf fg]# find /var/ -user root -group mail -ls
44906    0 drwxrwxr-x   2 root     mail          226 8月 23 04:11 /var/spool/mail
```
						
2、查找/usr目录下不属于root，bin或hadoop的所有文件和目录，用两种方法；
```
[root@luqyf fg]# find /usr/ -not -user root  -not -user bin -ls
33768317    0 drwx------   2 polkitd  root            6 4月 11 08:27 /usr/share/polkit-1/rules.d
[root@luqyf fg]# find /usr/ -not \( -user root -o -user bin \) -ls
33768317    0 drwx------   2 polkitd  root            6 4月 11 08:27 /usr/share/polkit-1/rules.d
```

3、查找/etc目录下最近一周内其内容修改过，且属主不是root用户也不是hadoop用户的文件或目录；
```
[root@luqyf fg]# find / -mtime -7 -a ! -user root  -ls -a ! -user bin
```
						
4、查找当前系统上没有属主或属组，且最近一周内曾被访问过的文件或目录；
```
[root@luqyf fg]# find / -nouser -ls -o -nogroup -a -atime -7
17149047    0 drwxrwx---   2 770      edu             6 8月 17 01:51 /oldboy/edu
```								
5、查找/etc目录下大于1M且类型为普通文件的所有文件；
```
[root@luqyf fg]# find /etc/ -size +1M -type f
/etc/udev/hwdb.bin
/etc/selinux/targeted/active/policy.kern
/etc/selinux/targeted/contexts/files/file_contexts.bin
/etc/selinux/targeted/policy/policy.31
```
				
6、查找/etc目录下所有用户都没有写权限的文件；
```
[root@luqyf fg]# find /etc/ ! -perm /222  -ls
```
7、查找/etc目录下至少有一类用户没有执行权限的文件；
```
[root@luqyf fg]# find /etc/  ! -perm -111  -ls
```

8、查找/etc/init.d目录下，所有用户都有执行权限，且其它用户有写权限的所有文件；
```
[root@luqyf fg]# find /etc/init.d/ -perm -111  -perm -002 -ls
```
## find和xargs的搭配：

### xargs常用选项

- [ ] -0，当sdtin含有特殊字元时候，将其当成一般字符，像/空格等，配合find的-print0
```
[root@oldboy ~]# touch "a b c.txt"
[root@oldboy ~]# find . -name "*.txt" |xargs ls
ls: 无法访问c.txt: 没有那个文件或目录
./a  b
[root@oldboy ~]# find . -name "*.txt" -print0 |xargs -0 ls
./a b c.txt
```
- [ ] -a file 从文件中读入作为sdtin
```
[root@oldboy ~]# cat 1.txt 
aaa  bbb ccc ddd
a  b
c  d
[root@oldboy ~]# xargs -a 1.txt 
aaa bbb ccc ddd a b c d
```
- [ ] -e flag ，注意有的时候可能会是-E，flag必须是一个以空格分隔的标志，当xargs分析到含有flag这个标志的时候就停止
```
[root@oldboy ~]# xargs -E 'ddd' -a 1.txt 
aaa bbb ccc
[root@oldboy ~]# cat 1.txt |xargs -E 'ddd'
aaa bbb ccc
```
- [ ] -n num 后面加次数，表示命令在执行的时候一次用的argument的个数，默认是用所有的。
```
[root@oldboy ~]# cat 1.txt |xargs -n 2
aaa bbb
ccc ddd
a b
c d
```
- [ ] -p 操作具有可交互性，每次执行comand都交互式提示用户选择，当每次执行一个argument的时候询问一次用户
```
[root@oldboy ~]# cat 1.txt |xargs -p
echo aaa bbb ccc ddd a b c d ?...y
aaa bbb ccc ddd a b c d
```
- [ ] -i 或者是-I，这得看linux支持了，将xargs的每项名称，一般是一行一行赋值给{}，可以用{}代替
```
[root@oldboy ~]# touch {1..10}.txt
解法一：使用cp -t,xargs -t 查看执行命令细节
find -name "*.txt" |xargs [-t] cp -t /tmp/
解法二：
cp [-v] `find /root -name "*.txt"` /tmp
cp [-v] $(find /root -name "*.txt") /tmp
解法三：
find -name "*.txt" -exec cp [-v] {} /tmp \;
解法四：
[root@oldboy ~]# find . -name "*.txt" |xargs -I {} cp [-v] {} /var/tmp
```
