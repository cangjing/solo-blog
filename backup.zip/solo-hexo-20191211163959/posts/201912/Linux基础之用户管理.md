title: Linux基础之用户管理
date: '2019-12-08 21:04:52'
updated: '2019-12-08 21:10:07'
tags: [运维基础]
permalink: /articles/2019/12/08/1575810292135.html
---
# Linux系统用户管理
- [ ] 一切基础皆重点
>1.用户管理*****
2.Linux用户命令****
3.用户创建的原理***
4.密码管理***
5.组命令管理**
6.身份切换*****
7.sudo提升权限*****

- [ ] 我们现在所使用的操作系统都是多用户操作系统
>AAA 认证体系\
认证 授权 审计

- [ ] 用户和组存在的意义
>1.系统上的每一个进程(运行的程序)都需要特定的用户运行
2.每一个文件都有特定的用户拥有
3.访问文件或目录受到用户的限制
4.进程能够以何种方式访问某一个文件或目录, 与进程所关联的用户有关

- [ ] 查看当前登录的用户信息
```
[root@oldboy /]# id
uid=0(root) gid=0(root) groups=0(root) 
```
- [ ] **用户uid的分类**
>0-65535\
0 超级管理员\
1-200 系统用户，由系统分配给系统进程使用\
201-999 系统用户，用来运行服务账户，不需要登陆系统(动态分配)\
1000+常规用户注意: 在Linux7之前的惯例是, UID1-499用于系统用户, 而UID 500+则用于普通用户。

- [ ] 组类别
>基本组\
优先使用基本组, 用户只能属于一个基本组, 用户默认基本组\
附加组 \
基本组不能满足授权要求, 创建附加组, 用户可以属于多个附加组 私有组 私有组, 创建用户时如果没有指定基本组, 系统会创建和用户同名的组

***
## 1.用户管理
>账户信息存放在/etc/passwd，账户密码信息保存在/etc/shadow，这两个文件是linux系统中最重要的文件之一。 如果没有这两个文件或者这两个文件出问题，会导致无法正常登录linux系统。

### /etc/passwd 账户文件：
```
[root@oldboy ~]# head -1 /etc/passwd
root:x:0:0:root:/root:/bin/bash
```
- [ ] /etc/passwd由':'分割成7个字段，每个字段的具体含义如下:

| 字段名称       |    注释说明 | 
| :-------- | --------| 
| 1.用户名称 | //用户的账号名称| 
| 2.密码占位符   |//存放账户的口令,暂用x表示,密码保存在/etc/shadow| 
|3.用户的UID   |  //用户标识号 |
| 4.用户基本组GID     |  //组标识号| 
| 5.用户注释    |  //用户详细信息 |
| 6.用户家目录 |  在/home/username，可自定义 | 
| 7.用户登录Shell | //用户登录Linux使用的shell cat /etc/shells |

***

### /etc/shadow 用户密码文件：
```
[root@oldboy ~]# tail -1 /etc/shadow
zhangsan:$6$XfGKMLdW$y2Viu1KB3Obvcx8wDuvc0Hy.4Vqyg5.XlpbwpsFFu8SKJ8typsWln6pqLX/yvjkySS1ZS0PhD54WyUnXBK.cC.:16314:2:15:6:5:16678:
```
//  /etc/shadow由':'分割成9个字段，每个字段的具体含义如下：
         
| 字段名称   |  注释说明 | 
| :-------- | --------| 
| 1.用户登陆名 |    //用户的账号名称  |  
| 2.加密后的密码   | //用户密码,这是加密过的口令(未设密码时为！！) |  
| 3.最近一次密码更改时间    | //从1970年到最近一次更改密码时间之间过了多少天|
| 4.密码最少使用几天| //密码最少使用几天才可以更改密码(0表示无限制)	 | 
| 5.密码最长使用几天   |//密码使用多少天需要修改密码(默认99999永不过期) |  
| 6.密码到期前警告期限|//密码过期前多少天提醒用户更改密码(默认过期提前7天警告) | 
|7.密码到期后保持活动的天数  |//在此期限内, 用户依然可以登陆系统并更改密码, 指定天数过后, 账户被锁定		 | 
| 8.账户到期时间  | //从1970年起,账户在这个日期前可使用，到期后失效。| 
| 9.标志   |  //保留 | 
-  [ ] 密码格式
-  \$a]\$b$c
>	a 表示加密算法
	b salt 随机值
	c 加密后的值

***
## 命令-------chage	
- [ ] 使用chage更改用户密码密码使用情况
chage  【选项】 【指定用户】

**-d** 设置最近一次更改密码时间, 0下次登陆系统强制修改密码

> [root@oldboy ~]# chage -d "2014-09-01" oldboy1\
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:==16314==:0:99999:7:::

**-m** 设置用户两次改变密码之间使用"最小天数"
> [root@oldboy ~]# chage -m 2 oldboy1\
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:==2==:99999:7:::

**-M**设置用户两次改变密码之间使用"最大天数"
> [root@oldboy ~]# chage -M 15 oldboy1\
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:==15==:7:::

**-W** 设置密码更改警告时间 将过期警告天数设为“警告天数”
> [root@oldboy ~]# chage -W 6 oldboy1\
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:==6==:::

**-I** 设置密码过期天数后, 密码为失效状态(大写i)

>[root@oldboy ~]# chage -I 5 oldboy1
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:6:==5==::

**-E** 设置用户过期时间, 账户失效后无法登陆
>[root@oldboy ~]# chage -E "2015-08-31" oldboy1
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:6:5:==16678==:

**-l** 显示用户信息（小写l）
```
[root@oldboy ~]# chage -l oldboy1
Last password change            : Sep 01, 2014            //最近一次更改密码时间
Password expires                : Sep 16, 2014            //密码过期时间
Password inactive               : Sep 21, 2014            //密码失效时间
Account expires                 : Aug 31, 2015            //用户失效时间
Minimum number of days between password change      : 2   //密码最短使用时间
Maximum number of days between password change      : 15  //密码最长使用时间
Number of days of warning before password expires   : 6   //密码过期前警告天数
```

***
- [ ] **实验**：
//修改时间为2014年08月31日,和图中时间匹配,方便后续验证
```
[root@oldboy ~]# date -s '20140831'                          #更改时间
Sun Aug 31 00:00:00 CST 2014
[root@oldboy ~]# date				                        #查看时间
Sun Aug 31 00:00:01 CST 2014
[root@oldboy ~]# usereadd oldboy1	                        #创建实验用户oldboy1
[root@oldboy ~]# echo "123" |passwd --stdin oldboy1 		#给用户oldboy1设置密码
[root@oldboy ~]# tail -1 /etc/shadow					    #查看文件中密码信息
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16312:0:99999:7:::
```
//设置最近一次修改密码时间
```
[root@oldboy ~]# chage -d "2014-09-01" oldboy1
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:0:99999:7:::
```
//设置最短使用密码时间
```
[root@oldboy ~]# chage -m 2 oldboy1
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:==2==:99999:7:::
倘若用户此时想修改密码就会报错：
You must wait longer to change your password   ：#您必须等待更长时间以更改密码
passwd: Authentication token manipulation error
```
//设置密码最长使用时间
```
[root@oldboy ~]# chage -M 15 oldboy1
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:7:::
```
//设置密码警告时间
```
[root@oldboy ~]# chage -W 6 oldboy1
[root@oldboy ~]# tail -1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:6:::
```
//设置密码过期时间
```
[root@oldboy ~]# chage -I 5 oldboy1
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:6:5:
```
//设置用户过期时间
```
[root@oldboy ~]# chage -E "2015-08-31" oldboy1
[root@oldboy ~]# tail -n1 /etc/shadow
oldboy1:$6$mXhY8urU$fXeKVr6DaEYd5tJPpqB3TjGK1TlRv5v2JX5piVUXX79GeWPo4X5mBu3DNm2vzVLk61MXiRsS9Ebuqy0JRCRR30:16314:2:15:6:5:16678:
```
查看信息
```
[root@oldboy ~]# chage -l oldboy1
Last password change            : Sep 01, 2014            //最近一次更改密码时间
Password expires                : Sep 16, 2014            //密码过期时间
Password inactive               : Sep 21, 2014            //密码失效时间
Account expires                 : Aug 31, 2015            //用户失效时间
Minimum number of days between password change      : 2   //密码最短使用时间
Maximum number of days between password change      : 15  //密码最长使用时间
Number of days of warning before password expires   : 6   //密码过期前警告天数
```
- [ ] //如何验证,只调整时间为如下进行验证:

1.验证普通用户是否能修改密码, 不需要调整时间。\
2.普通用户登陆系统后, 会提示警告密码还剩多少天过期
```
[root@oldboy ~]# date -s "2014-09-12"
此时在用普通用户登录就提示：
Warning: your password will expire in 5 days  #警告：您的密码将在5天内到期
```
3.普通用户登陆系统后, 强制要求修改密码
```
[root@oldboy ~]# date -s "2014-09-18"
此时在用普通用户登录就提示
WARNING: Your password has expired  #警告：您的密码已过期
```
4.普通用户登陆系统后, 提示账户已过期
```
[root@oldboy ~]# date -s "2014-09-23"
此时在用普通用户登录就提示
账户过期，不能登录
```


***
## 2.Linux用户命令
**添加用户前需要确定**
- 确定用户的默认组是否有特殊要求
- 确定用户是否允许登陆	
- 确定用户的密码策略
- 确定用户的有效期	
- 确定用户的uid是否有特殊要求

### 命令：useradd
1. 使用useradd命令新增账户
- 注意: adduser命令软链接指向useradd命令
>'-u'  指定用户的UID,不能和现有ID冲突\
'-g'  指定用户用户默认基本组\
'-G'  指定用户附加组,用逗号隔开添加多个附加组\
'-d'  指定用户家目录\
'-c'  指定用户注释信息\
'-M'  不建立家目录\
'-s'  指定用户默认shell\
'-r'  创建系统账户, 没有家目录

//创建oldboy用户,指定UID5001,基本组,students 附加组:sa,dba, 注
```
[root@oldboy ~]# groupadd sa		#先建立sa，与dba组
[root@oldboy ~]# groupadd dba
[root@oldboy ~]# groupadd students
[root@oldboy ~]# useradd -u 5001 -g students -G sa,dba -c "2018 new student" -d /home/oldgirl -s /bin/bash oldgirl
[root@oldboy ~]# tail -1 /etc/passwd
oldgirl:x:5001:1004:2018 new student:/home/oldgirl:/bin/bash
```

//创建系统用户，-M不建立用户家目录 -s指定nologin使其用户无法登陆系统
```
[root@localhost ~]# useradd -M -s /sbin/nologin user
[root@localhost ~]# tail -1 /etc/passwd
user:x:5002:5002::/home/user:/sbin/nologin
[root@localhost ~]# useradd -r -s /sbin/nologin user1
[root@localhost ~]# tail -1 /etc/passwd
user1:x:998:996::/home/user1:/sbin/nologin
区别：-M -s 用户和组ip都属于普通用户范围，精确的用-r -s
```

### 命令：usermod
- [ ] 使用usermod命令修改用户组
>'-u'    修改用户的UID\
'-g'    修改用户所属的基本组GID\
'-G'    修改用户附加组, 使用逗号隔开多个附加组, 覆盖原有的附加组\
'-a'    追加更多的附加组, 必须和-G使用: -aG 追加附加组\
'-md'   家目录迁移, 必须和-d一起使用, 移动用户的家目录到新的位置\
'-d'    指定用户的家目录新位置 \
'-c'    修改用户的注释信息 \
'-s'    更改用户使用的shell\
'-l'    更改用户登录名\
'-L'    锁定用户\
'-U'    解锁用户

//修改用户uid,gid, 附加组, 注释信息, 用户家目录, 登录shell, 登录名
```
[root@oldboy ~]# grep "oldgirl" /etc/passwd
oldgirl:x:5001:1004:2018 new student:/home/oldgirl:/bin/bash
```

//建立组,指定组gid
```
[root@oldboy ~]# groupadd -g 5008 network_sa
[root@oldboy ~]# groupadd -g 5009 devops
```
//修改用户属性
```
[root@oldboy ~]# usermod -u 6001 -g5008 -a -G 5009 -c "2019 new student" -md /oldgirl -s /bin/sh -l oldstudent oldgirl
```
//检查是否修改成功
```
[root@oldboy ~]# tail -1 /etc/passwd
oldstudent:x:6001:5008:2019 new student:/oldgirl:/bin/sh
```
//查看用户id
```
[root@oldboy ~]# id oldstudent
uid=6001(oldstudent) gid=5008(network_sa) groups=5008(network_sa),1002(sa),1003(dba),5009(devops)

[root@oldboy ~]# tail -1 /etc/passwd
oldstudent:x:6001:5008:2019 new student:/oldgirl:/bin/sh
```
//验证家目录
```
[root@oldboy ~]# ll -d /oldgirl/
drwx------. 2 oldstudent network_sa 62 Sep 23 00:07 /oldgirl/
```
- [ ] **锁定用户**
```
[root@oldboy ~]# echo "123" |passwd --stdin oldstudent
[root@oldboy ~]# usermod -L oldstudent
//无法正常登录系统
➜  ~ ssh oldstudent@10.0.0.200
oldstudent@10.0.0.200's password
:Permission denied, please try again.
```
- [ ] **解锁用户**
```
[root@oldboy ~]# usermod -U oldstudent
//正常登录系统
```
- [ ] 使用finger命名查询用户信息以及登录信息
- //安装finger命令
`
yum install -y finger
`
```
[root@oldboy ~]# finger oldstudent
Login: oldstudent               Name: 2019 new student
Directory: /oldgirl                     Shell: /bin/sh
On since Tue Sep 23 00:19 (CST) on pts/0 from 10.0.0.1
   8 seconds idle
No mail.
No Plan
```

- [ ] 使用chfn修改用户信息
```
[root@oldboy ~]# chfn oldstudent
Changing finger information for oldstudent.
Name [2019 new student]: 2018 new student
Office []: oldboy 2009
Office Phone []: 12345678
Home Phone []: 18995568216

Finger information changed.
```

//使用finger再次检查
```
[root@oldboy ~]# finger oldstudent
Login: oldstudent               Name: 2018 new student
Directory: /oldgirl                     Shell: /bin/sh
Office: oldboy 2009, 12345678       Home Phone: +1-899-556-8216
On since Tue Sep 23 00:19 (CST) on pts/0 from 192.168.119.1
   1 minute 25 seconds idle
No mail.
No Plan.
```

- [ ] 使用chsh命令更改用户登录shell
```
[root@oldboy ~]# chsh oldstudent
Changing shell for oldstudent.
New shell [/bin/sh]: /bin/bash
Shell changed.
[root@oldboy ~]# grep "oldstudent" /etc/passwd
oldstudent:x:6001:5008:2018 new student,oldboy 2009,12345678,18995568216:/oldgirl:/bin/sh
```

### 检查用户登陆情况
```
[root@oldboy ~]# who
oldboy  pts/0        2017-10-30 09:30 (10.0.0.1)
oldgirl pts/1        2014-09-23 01:33 (10.0.0.1)
root    pts/2        2017-10-30 07:13 (10.0.0.1)
```
```
[root@oldboy ~]# w
 01:43:18 up 1 day, 15:00,  3 users,  load average: 0.00, 0.00, 0.00
USER     TTY      FROM              LOGIN@   IDLE   JCPU   PCPU WHAT
oldboy  pts/0    10.0.0.1     09:30     ?     0.35s  0.18s sshd: xu
oldgirl pts/1    10.0.0.1     01:33    9:24   0.03s  0.00s bash
root    pts/2    10.0.0.1     07:13    0.00s  1.49s  0.08s w
```

### 使用userdel删除账户
```
语法 : userdel [-r] username //-r 同时删除家目录
[root@oldboy ~]# userdel user1
[root@oldboy ~]# ll /home/user1/ -d
drwx------. 3 501 501 4096 2017-11-15 12:40 /home/user1/
发现默认没有删除家目录，如何要一同删除家目录，加-r参数
```
//连同家目录一起删除
```
[root@oldboy ~]# userdel -r user1
```
***
## 3.用户创建的原理
Linux创建用户默认会读取/etc/defaults/useradd的配置文件，如果当我指定参数时，使用指定参数，如果不指定参数，默认使用/etc/defaults/useradd中的配置。

当我们使用useradd命令新建用户时，用户家目录下会产生相应的.bash_*文件，这些文件默认是从/etc/skel目录中复制。如需变更环境拷贝目录站点可修改:/etc/defaults/useradd的配置文件。 

注意：如果执行useradd命令新建用户时，指定了参数，就会覆盖/etc/default/useradd默认的配置。
```
[root@student ~]# egrep -v "^#|^$" /etc/login.defs
MAIL_DIR    /var/spool/mail
PASS_MAX_DAYS   99999                    #密码最长过期时间
PASS_MIN_DAYS   0                         #密码最短过期时间
PASS_MIN_LEN    5                         #密码最小长度
PASS_WARN_AGE   7                         #密码过期提前提醒时间
UID_MIN                  1000             #uid最小值
UID_MAX                 60000             #uid最大值
SYS_UID_MIN               201             #系统用户uid最小值
SYS_UID_MAX               999             #系统用户uid最大值
GID_MIN                  1000             #gid最小值
GID_MAX                 60000            #gid最大值
SYS_GID_MIN               201             #系统组gid最小值
SYS_GID_MAX               999             #系统组gid最大值
CREATE_HOME yes                           #是否同时建立家目录
UMASK           077                      #创建后用户的权限掩码
USERGROUPS_ENAB yes                 #创建用户时是否同时创建相同用户组名
ENCRYPT_METHOD SHA512              #加密方式为SHA512
```
```
[root@student ~]# cat /etc/default/useradd
GROUP=100
HOME=/home                  //把用户的家目录建在/home中。
INACTIVE=-1                 //是否启用账号过期停权,-1表示不启用。
EXPIRE=                     //账号终止日期,不设置表示不启用。
SHELL=/bin/bash             //新用户默认所有的shell类型。
SKEL=/etc/skel              //配置新用户家目录的默认文件存放路径。
CREATE_MAIL_SPOOL=yes       //创建mail文件。
```
//用户登录linux操作系统，环境变量被误删，出现-bash-4.2$，如何解决！
```
-bash-4.2$ cp -a /etc/skel/.bash* ./
-bash-4.2$ exit

[root@student ~]# su - oldboy
[oldboy@student ~]$
```
## 4.密码管理
创建完账户后，默认是没有设置密码的，所以该账户是没有办法登陆操作系统。只有使用passwd设置好密码后方可登录系统。 

使用passwd为用户创建密码时，为了安全起见，请尽量设置复杂一些。可以按照如下规则设置密码：
>1.长度大于10位字符;\
2.密码中包含大小写字母数字以及特殊字符 ‘!’,’@’,’$’等； \
3.不规则性（不要出现自己名字、公司名字、自己电话、等等简单的密码)

**需要注意**:
1. 普通用户只能更改自己的密码
2. 管理员root能更改任何人密码
- [ ] 用passwd命令修改用户密码
- 语法 : passwd [username]
>// 'passwd' 后面不加username则是修改当前账户的密码。\
//如果你登陆的是root账户，后面可以指定要修改密码的账户。\
//只有root才可以修该其他账户的密码，普通账户只能修改自己的密码，普通用户没有修改其他用户的权限

//root用户登陆，修改root账户密码
```
[root@oldboy ~]# passwd  
更改用户 root 的密码 。
新的 密码：
重新输入新的 密码：
passwd： 所有的身份验证令牌已经成功更新。
```
//root用户登陆，修改oldboy1账户密码
```
[root@oldboy ~]# passwd oldboy
更改用户 user11 的密码 。
新的 密码：
重新输入新的 密码：
passwd： 所有的身份验证令牌已经成功更新。
```
//普通用户修改root密码
```
[oldstudent@oldboy ~]$ passwd root
passwd: Only root can specify a user name.
```
//.无需用户交互修改密码, 将前者的输出结果, 成为后者的输入
```
[root@oldboy ~]# echo "123" | passwd --stdin oldstudent
Changing password for user oldstudent.
passwd: all authentication tokens updated successfully.
```
### 随机密码生成工具几种方式：
//1.系统内置变量生成随机密码
```
[root@oldboy ~]# echo $RANDOM|md5sum|cut -c 1-10
d09fe9b1xs
```
//2.mkpasswd密码生成工具
//-l密码长度默认7位, -d数字, -c小写字母,-C大写字母
```
[root@oldboy ~]# yum install -y expect   //需要安装扩展包
[root@oldboy ~]# mkpasswd -l 15 -d 3 -C 5
yB7LpqIM31>ktpB
推荐密码保存工具客户端，支持windows、MacOS、手机、以及浏览器插件 
Lastpass官方网站
```
***
## 组命令管理
组账户信息保存在/etc/group和/etc/gshadow两个文件中。

**/etc/group** 组账户信息
>[root@oldboy ~]# head -2 /etc/group\
root:x:0:\
bin:x:1:bin,daemon

/etc/group由 ':' 分割成4个字段，每个字段的具体含义如下:
       
| 字段名称  |    注释说明 | 
| :-------- | --------| 
| 1.组账户名称  | //组的名称|    
| 2.密码占位符  | //组的密码(存在/etc/gshadow) | 
|3.组GID  |//组GID信息| 
| 4.组成员    |  //这里仅显示附加成员,基本成员不显示 | 
***
**/etc/gshadow**组密码信息文件
>root@oldboy ~]# head -2 /etc/gshadow\
root:::\
bin:::bin,daemon\

// /etc/gshadow由 ':' 分割成4个字段，每个字段的具体含义如下:
           
| 字段名称      |  注释说明 |
| :-------- | --------| 
| 1.组账户名称   | //组名称 | 
| 2.密码占位符  | //组密码|  
| 3.组管理员  |  //组管理员 | 
|  4.组成员    | //这里仅显示附加成员,基本成员不显示 | 

### groupadd-----新增组
语法 : groupadd [-g GID] groupname

//不指定gid默认从1000开始
```
[root@oldboy ~]# groupadd gtest
[root@oldboy ~]# tail -1 /etc/group
gtest:x:1000:
```
//"-g"指定gid
```
[root@oldboy ~]# groupadd -g 5555 gtest2
[root@oldboy ~]# tail -1 /etc/group
gtest2:x:5555:
```
//"-r"创建系统组，gid从201-999
```
[root@oldboy ~]# groupadd -r test_test
[root@oldboy ~]# tail -1 /etc/group
test_test:x:990:
```
***

### groupmod----修改组
//新建一个用户组
```
[root@oldboy ~]# groupadd oldboy_test
[root@oldboy ~]# tail -1 /etc/group
oldboy_test:x:5010:
```
//-g 修改组gid
```
[root@oldboy ~]# groupmod -g 5555 oldboy_test
[root@oldboy ~]# tail -1 /etc/group
oldboy_test:x:5555:
```
//-n 修改组名称
```
[root@oldboy ~]# groupmod -n oldboy_modfiy oldboy_test
[root@oldboy ~]# tail -1 /etc/group
oldboy_modfiy:x:5555:
```

### 使用groupdel删除组
//该命令没有特殊选项，如果一个用户有基本组和附加组,只能删除附加组,不能删除基本组

//删除组
```
[root@oldboy ~]# groupdel oldboy_modfiy
```
//删除用户附加组
```
[root@oldboy ~]# tail -1 /etc/group
devops:x:5009:oldstudent
[root@oldboy ~]# groupdel devops
```

//无法删除用户基本组
```
[root@oldboy ~]# tail -n1 /etc/group
network_sa:x:5008:
[root@oldboy ~]# groupdel network_sa
groupdel: cannot remove the primary group of user 'oldboy'
//只有删除用户或者用户变更基本组后,方可删除该组
```

### 使用gpasswd设置组密码
```
[root@oldboy ~]# groupadd devops
[root@oldboy ~]# gpasswd devops
Changing the password for group devops
New Password:
Re-enter new password:
```
使用newgrp命令切换基本组身份

//检查账户信息
```
[root@oldboy ~]# id oldboy
uid=6001(oldboy) gid=5008(network_sa) groups=5008(network_sa),503(sa),504(dba)
```
//切换普通用户
```
[root@oldboy ~]# su - oldboy
```
//创建新文件,并验证权限
```
[oldboy@oldboy ~]$ touch group_test
[oldboy@oldboy ~]$ ll
total 0
-rw-r--r--. 1 oldboy network_sa 0 2014-09-23 01:58 group_test
```
//切换组信息
```
[oldboy@oldboy ~]$ newgrp devops
Password:
[oldboy@oldboy ~]$ id
uid=6001(oldboy) gid=5009(devops) groups=5009(devops),503(sa),504(dba),5008(network_sa) context=unconfined_u:unconfined_r:unconfined_t:s0-s0:c0.c1023
```

//建立文件,检查权限
```
[oldboy@oldboy ~]$ touch group_new
[oldboy@oldboy ~]$ ll
total 0
-rw-r--r--. 1 oldboy devops     0 Sep 23 01:59 group_new
-rw-r--r--. 1 oldboy network_sa 0 Sep 23 01:58 group_test
```

### gpasswd命令
功能：管理组\
用法：gpasswd[-a user][-d user][-A user,...][-M user,...][-r][-R]groupname\
参数：\
gpasswd <group> 			#设置组密码
```
[root@oldboy ~]# groupadd shiyan
[root@oldboy ~]# gpasswd shiyan
Changing the password for group shiyan
New Password:
Re-enter new password:
[root@localhost ~]# tail -1 /etc/gshadow
shiyan:$6$.iWYD/GEE7u/Qm$3/UuRkn4.0tAkJlsw3FGnp0rrkOHLfwHi9PebXBwXs45d/NOq.9L9X1jKqgRvdDs5iHF7LNo3erWPFlzQHKzM/:user3:
为实验组设置密码
```

**-r**：删除密码				  gpasswd -r <group>    <==刪除群組密碼
```
[root@localhost ~]# gpasswd -r shiyan
[root@localhost ~]# tail -1 /etc/gshadowshiyan::user3:
```
**-a**：添加用户到组		用法：gpasswd -a <user> <group>  <==加入使用者到特定群組
```
[root@localhost ~]# gpasswd -a user3 user
正在将用户“user3”加入到“user”组中
[root@localhost ~]# tail -1 /etc/group
user:x:1001:user3
#将用户user3加入到user中
```

**-d**：从组删除用户			   gpasswd -d <user> <group>  <==刪除在特定群組的使用者
```
[root@localhost ~]# gpasswd -d user3 user
正在将用户“user3”从“user”组中删除
[root@localhost ~]# tail -1 /etc/group
user:x:1001:
```
**-A**：指定管理员			   gpasswd -A <user> <group>  <==加入管理者到特定群組
```
[root@localhost ~]# gpasswd -A user3 shiyan
[root@localhost ~]# tail -3 /etc/gshadow
shiyan:!:user3:
```

**-M**：指定组成员和-A的用途差不多
```
[root@localhost ~]# gpasswd -M mike,teacher adm 
将用户Mike，teacher同时加入到adm组中
```
**-R**：限制用户登入组，只有组中的成员才可以用newgrp加入该组  
gpasswd -R <group>  <==加入群組密碼（需與gpasswd <group>聯用）
```
[root@localhost ~]# gpasswd -R shiyan
```

***
## 身份切换-
Linux系统中，有时候普通用户有些事情是没办法操作，除非是root用户才能做到。这时就需要临时切换到root身份来做事了。那么在学习如何切换用户之前,我们先来了解下用户工作环境。

### Shell分类：
>**交互式shell**    等待用户输入执行提交的命令（终端操作）, exit退出\
**非交互式shell**   执行shell脚本, 脚本执行结束shell自动退出\
1.把交互命令换成同等功能非交互命令\
2.提前做好应答文件\
**登陆shell**     需要输入用户名和密码才能进入shell, su - oldboy\
**非登陆shell**  不需要输入用户和密码就能进入,比如执行, sh, bash

### //查看登陆shell
```
[root@oldboy ~]# pstree
```

//临时设置,永久设置需要写配置文件
```
[root@oldboy ~]# export PS1='[\h@\u \t]#'
[oldboy@root 02:06:28]#
bash配置文件
Bash的配置文件保存用户的工作环境
```
### 个人配置文件：
```
 ~/.bash_profile ~/.bashrc
```
### 全局配置文件：
```
/etc/profile /etc/profile.d/*.sh /etc/bashrc
```
### 字符串环境变量文件：
```
/etc/locale.conf （CentOS7）
```
profile类文件, 设定环境变量, 登陆前运行的脚本和命令\
bashrc 类文件, 设定本地变量, 定义命令别名

全局配置和个人配置设置冲突, 以个人设置为准\
shell配置文件应用顺序

### //登录式shell配置文件执行顺序

>/etc/profile->/etc/profile.d/*.sh->~/.bash_profile->~/.bashrc->/etc/bashrc

### //非登陆式shell配置文件执行顺序

>~/.bashrc->/etc/bashrc->/etc/profile.d/*.sh

//如何验证登陆shell和非登陆shell,配置文件执行顺序, 只需要在每个配置文件加入一段 “echo”即可。\
	注意：添加的echo字段必须放在第二行
	
//最后通过登陆shell和非登录shell方式登陆linux, 即可验证执行顺序。
如果全局配置和个人配置出现冲突, 那么如何验证呢？
```
编辑全局配置 /etc/profile     新增一行： PS1='[\h@\u \t]#'
[oldboy@root 02:16:57]#     //当前终端shell环境

编辑个人配置 /home/oldboy/.bash_profile     新增一行： PS1='[\u@\H]#'

[oldboy@root 02:18:27]#su  oldboy
[oldboy@oldboy root]$

[oldboy@root 02:18:34]# su - oldboy
[oldboy@oldboy.com]#

创建用户，并登录系统
[root@oldboy ~]# useradd oldboy
[root@oldboy ~]# echo "123"|passwd --stdin oldboy
更改用户 oldboy 的密码 。
passwd： 所有的身份验证令牌已经成功更新。

//使用oldboy用户登录Linux
➜  ~ ssh oldboy@10.0.0.200
oldboy@10.0.0.200's password:
Last login: Sun Nov  5 17:23:06 2017 from 10.0.0.200
[oldboy@oldboy ~]$

//可以使用whoami查看当前登录用户
[oldboy@oldboy ~]$ whoami
oldboy

切换用户，使用命令su [-] username 
su命令后面跟 - 代表进入登陆式shell 否则代表进入非登陆式shell 只不过他们所执行的环境变量配置文件不一样。 
普通用户su -不加username时可以切换root用户, 但需要输入密码。 
超级管理员root用户使用su -切换普通用户不需要密码。
[oldboy@oldboy ~]$ pwd
/home/oldboy


//不加 '-' 切换到root账户下时，当前目录没有变化
[oldboy@oldboy ~]$ su
密码：
[root@oldboy oldboy]# pwd
/home/oldboy
[root@oldboy oldboy]# exit
exit

//加上 '-' 切换到root账户后，当前目录为root账户的家目录。
//当用root切换普通用户时，是不需要输入密码的。
[oldboy@oldboy ~]$ su -
密码：
[root@oldboy ~]# pwd
/root
以某个用户的身份执行某个服务，使用命令su -c username

[root@oldboy ~]# su - oldboy -c 'ifconfig'
[root@oldboy ~]# su - oldboy -c 'ls ~'
```

### sudo提升权限

su切换用户身份，如果每个普通用户都能切换到root身份，如果某个用户不小心泄漏了root的密码，那系统会变得非常不安全。

为了改进这个问题，从而产生了sudo这个命令。使用sudo执行一个root才能执行的命令是可以办到的，但是需要输入密码，这个密码并不是root的密码而是用户自己的密码。

默认只有root用户能使用sudo命令，普通用户想要使用sudo，是需要root预先设定的，即，使用 visudo命令去编辑相关的配置文件/etc/sudoers

//Centos7提权方法，授权用户具有管理员所有的权限
```
[root@oldboy ~]# usermod -G wheel oldboy
```
//日志审计
```
[root@oldboy ~]$ sudo tail -f /var/log/secure
系统安装后就有sudo命令，如果没有sudo命令，可通过如下方式安装
[root@oldboy ~]# yum install -y sudo
```
使用visudo命令编辑/etc/sudoers配置文件
//执行visudo，等于使用vi编辑sudoers配置文件

>//默认权限
==root  ALL=(ALL) ALL==\
**sudo配置选项详解**\
//下面解释如上每行代表含义\
**//1.用户名/组名       2.主机名 （角色名 ）      4.命令名**\
root            ALL=    (ALL)           ALL\
oldboy        ALL     使用最高角色执行    /bin/rm, /bin/cp    //执行命令\
oldboy        ALL=(ALL)  NOPASSWD:/bin/cp, /bin/rm   //不需要密码使用rm、cp命令\
**//新增**\
oldboy ALL=(ALL) /bin/rm,/bin/cp\
//root默认就拥有sudo最高权限，我们在该行下新增oldboy用户，让此用户拥有sudo权限


案例需求：
要求oldboy用户能够添加删除修改所有用户属性（包括密码），但不包括root用户
```
[root@localhost ~]#visudo
oldboy  ALL=(ALL) /usr/sbin/user*,/usr/bin/passwd,!/usr/sbin/usermod * root,!/usr/bin/passwd * root,!/usr/bin/passwd root
```
### sudo别名：
```
User_Alias  USER = oldboy,test1,test2,%dba
Cmnd_Alias CMD = /usr/sbin/user*,/usr/bin/passwd,!/usr/sbin/usermod * root,/usr/bin/passwd,!/usr/bin/passwd root,!/usr/bin/passwd * root
USER    ALL=(ALL)       CMD
```
//使用visudo -c检查配置文件
```
[root@oldboy ~]# visudo  -c
/etc/sudoers: parsed OK
```

普通用户验证sudo权限
//切换普通用户
```
[root@oldboy ~]# su - oldboy
```
//检查普通用户sudo权限明细
```
[oldboy@oldboy ~]$ sudo -l
...省略部分
User oldboy may run the following commands on this host:
    (ALL) /bin/rm, (ALL) /bin/cp
```

//普通用户删除opt目录,删除失败
```
[oldboy@oldboy ~]$ rm -rf /opt/
rm: cannot remove `/opt': Permission denied
```
//使用sudo提权，验证用户权限是否可用，需要输入普通用户的密码
```
[oldboy@oldboy ~]$ sudo rm -rf /opt
```
***
### sudo免密码配置选项
```
//普通用户执行sudo不需要输入密码配置
[root@oldboy ~]# visudo
//修改前
oldboy ALL=(ALL) /bin/rm, /bin/cp
//修改后
oldboy   ALL=(ALL)  NOPASSWD:/bin/rm, /bin/cp
//默认普通用户无权删除
[oldboy@oldboy ~]$ rm -f /root/002
rm: cannot remove `/root/002': Permission denied
//验证sudo免密码执行权限
[oldboy@oldboy ~]$ sudo rm -f /root/002
```
sudo配置组：
//如果每增加一个用户需配置一行sudo，这样设置太麻烦了。所以可以进行如下设置：
```
//新增组
%oldboy  ALL=(ALL)     NOPASSWD:/bin/rm, /bin/cp
//group1这个组的所有用户都拥有sudo的权力。接下来只需要将用户加入该组即可。
//创建用户加入该组
[root@oldboy ~]# groupadd oldboy
[root@oldboy ~]# useradd oldboy -g oldboy
[root@oldboy ~]# useradd oldgirl -g oldboy
//root用户建立目录
[root@oldboy ~]# mkdir /root/oldboy_sudo
//切换用户并删除测试
[root@oldboy ~]# su - oldboy
[oldboy1@oldboy ~]$ rm -rf /root/oldboy_sudo
rm: cannot remove `/root/bgx_sudo': Permission denied
//使用sudo
[oldboy1@oldboy ~]$ sudo rm -rf /root/oldboy_sudo
当然配置文件/etc/sudoers包含了诸多配置项，可以使用命令 man sudoers 来获得帮助信息。
```
***
下面介绍一个很实用的案例，我们的需求是把Linux服务器设置成这个样子：只允许使用普通账户登陆Linux服务器，但可以让普通用户不输入密码就能sudo su -切换到root账户

//禁止root用户登陆
```
[root@oldboy ~]# sed -i  's@#PermitRootLogin yes@PermitRootLogin no@g' /etc/ssh/sshd_config
[root@oldboy ~]# systemctl restart sshd
```

//配置sudo权限
```
[root@oldboy ~]# visudo
User_Alias USER_SU = oldboy1,oldboy
Cmnd_Alias SU = /bin/su
USER_SU ALL=(ALL) NOPASSWD:SU
```
//使用root登陆服务器失败
```
➜  ~ ssh root@10.0.0.200
root@10.0.0.200's password:
Permission denied, please try again.
```
//使用普通用户登陆服务器
```
➜  ~ ssh oldboy@10.0.0.200
oldboy@10.0.0.200's password:
Last login: Mon Oct 30 09:28:21 2017 from 10.0.0.1
```
//使用sudo提权至root用户
```
[oldboy@oldboy ~]$ sudo su -
[root@oldboy ~]#
```
***
### sudo日志审计
通过sudo和syslog配合实现对所有用户进行权限的日志审计并将记录日志集中管理，实施后让所有运维和开发执行的sudo命令都有记录可查，杜绝了内部人员的操作安全隐患。 

sudo日志审计，专门针对sudo命令的系统用户记录其执行的命令相关信息，所谓sudo命令日志审计，并不记录普通用户的操作，而是记录执行sudo命令的用户操作。
记录所有的行为的文件就是日志

- [ ] /var/log/message  公共日志
时间：地点（主机名）：人物（进程）：信息
- [ ] /var/log/secure   用户安全日志

- [x] 安装sudo、rsysylog
```
[root@oldboy ~]# yum install -y sudo rsyslog
```
配置/etc/sudoers记录日志路径
```
[root@oldboy ~]# echo "Defaults  logfile=/var/log/sudo.log" >>/etc/sudoers
```
//查看追加的日志配置
```
[root@oldboy ~]# tail -1 /etc/sudoers  
Defaults  logfile=/var/log/sudo.log
```

//检查语法
```
[root@oldboy ~]# visudo -c     
/etc/sudoers: parsed OK 
```

配置rsyslog日志服务
```
[root@oldboy ~]# echo "local2.debug /var/log/sudo.log" >>/etc/rsyslog.conf 
```
//重启rsyslog服务
```
[root@oldboy ~]# systemctl restart rsyslog   
```
普通用户使用sudo权限验证日志记录
```
//使用普通执行sudo命令
[oldboy@oldboy ~]$ rm -rf /root/test/
rm: 无法删除"/root/test": 权限不够
[oldboy@oldboy ~]$ sudo rm -rf /root/test/
```
//检查用户在什么时间执行过什么操作
```
[oldboy@oldboy ~]$ tail /var/log/sudo.log
Nov  7 07:56:58 : oldboy : TTY=pts/1 ; PWD=/home/oldboy ; USER=root ;
    COMMAND=/bin/rm -rf /root/test/
     17874 
```
## 总结：
>用户组管理中的文件\
/etc/passwd\
用户组管理中的命令\
使用man，通过相应的章节来查阅\
[root@oldboyedu ~]# yum install -y man-pages man-pages-zh-CN\
**禁用用户的方法：**\
1.usermod -L\
在/etc/shadow，对应用户名的密码字段前加!\
2.passwd -l\
在/etc/shadow，对应用户名的密码字段前加!!
***

## 整理：
-  [ ] 用户信息文件
	/etc/passwd
	/etc/shadow
- [ ] 用户家目录
	/root
	/home/用户名
- [ ] 用户邮箱
	/var/spool/mail/用户名
- [ ] 用户模板目录
	/etc/skel
- [ ] 用户初始化文件
	/etc/defaults/useradd
	/etc/login.defs
- [ ] 组信息文件
	/etc/group
	/etc/gshadow
- [ ] 登录（环境）配置文件
	/etc/profile /etc/profile.d/* ~/.bash_profile
	/etc/bashrc ~/.bashrc
- [ ] 用户查看命令
	id w who whoami finger last
- [ ] 用户管理命令
	useradd usermod userdel passwd 
- [ ] 组查看命令
	groups
- [ ] 组管理命令
	groupadd groupmod groupdel gpasswd
