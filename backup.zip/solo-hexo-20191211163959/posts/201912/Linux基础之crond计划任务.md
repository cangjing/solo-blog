title: Linux基础之crond计划任务
date: '2019-12-08 20:55:33'
updated: '2019-12-08 20:55:33'
tags: [运维基础]
permalink: /articles/2019/12/08/1575809733745.html
---
# 计划任务
### CentOS计划任务：
1.at  -----atd
> 一次性计划任务

2.crontab ----  *****    ----- crond
> 用户级周期性计划任务，关机不执行

3.anacron
> 系统级周期性计划任务，开机后自动执行因企业要保证7*24，所以这个应用也不是必须的

#### 查看进程是否开启：
- [ ] 方法一：
```
[root@oldboy ~]# ps aux |grep crondroot        
523  0.0  0.0 126284  1620 ?        Ss   10:08   0:00 /usr/sbin/crond -nroot       
1690  0.0  0.0   9088   660 pts/0    R+   11:30   0:00 grep --color=auto crond
[root@oldboy ~]# ps aux |grep atd  root       
1692  0.0  0.0   9088   664 pts/0    R+   11:30   0:00 grep --color=auto atd
```
- [ ] 方法二：
```
systemctl status crond
systemctl status atd
```
- [x] 默认crond是已安装，切自动运行，atd是未安装的
```
yum install -y at	systemctl start atd
```
**注意**：只有进程启动了，才能提供计划任务的服务功能

### crond配置文件详解：
```
/etc/crontab		//crontab配置文件
/etc/cron.deny    //该文件中所有用户不允许使用的crontab命令
/var/spool/cron/*  //所有用户定时文件都存放在此目录，文件以用户名命名
/var/log/cron*/		//定时任务执行的日志文件，可用来回溯
```
### crontab时间含义：
```
vim /etc/crontab
SHELL=/bin/bash                         #通过bash解释命令
PATH=/sbin:/bin:/usr/sbin:/usr/bin      #默认命令路径
MAILTO=root							    #邮件信息发送给root


#For details see man 4 crontabs
#Example of job definition:
#.---------------- minute (0 - 59)
#|  .------------- hour (0 - 23)
#|  |  .---------- day of month (1 - 31)
#|  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ...
#|  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7) OR sun,mon,tue,wed,thu,fri,sat
#|  |  |  |  |
#*  *  *  *  * user-name  command to be executed
```


段 | 含义|  取值范围（整数|
---|---|---
第一段|分钟|00-59(00也可以是0)
第二段|小时|00-23
第三段| 天（日）|01-31
第四段| 月|01-12
第五段| 周|0-7（0和7代表都是星期日

符号含义：


| 符号 | 含义 | 
| --- | --- | 
| * | 号,表示任意时问都,实际就是“每”时间的意思. 表示任意的(分、时、日、月、周)时间都执行举例:如 00 23 * * * cmd表示每月每周每日的23:00都执行 cmd任务。需要注意的是:每个时间位上的*表示每,如果位上是*就是该位上时间的取值范国,例如:小时上的*等价于00-23。·经验技巧:定时任务规则如果到小时,就最多提每天。·分位上的*就等价于0-59,表示每分。 |  
| - | - 减号，表示分隔符，表示一个时间范围，区间段，如17-19点，每天的17，18，19的00分执行任务。00 17-19 * * * cmd。就是17，18，19点整点分别执行的意思。 |  
| , | , 逗号，表示分隔时间段的意思。30 12,18,20 * * */bin/sh /scripts/oldboy.sh ,表示每天12、18、20点的半点时刻执行 /scripts/oldboy.sh脚本。也可以和“-”结合使用，列如：30 3-5,17-19 * * * /bin/sh /scripts/oldboy.sh |  
| /n | n代表数字，即“每隔n单位时间”，例如：每十分钟执行一次任务可以写成*/10 * * * *cmd，其中,*/10,*的范围是0-59，因此，可以写成00-59/5 * * * * |  

### crontab选项：



参数| 含义|指示实例|
---|---|---
-l （字母） | 查看crontab文件内容。|crontab -l
-e | 编辑crontab文件内容|crontab -e
-i| 删除crontab文件内容，删除前会确认提示，用的很少|crontab -ri
-r| 删除crontab文件内容，用的很少|crontab -r
-u （user）| 指定使用的用户执行任务|crontab -u oldboy -l
- [ ] 特别强调：
```
-i ,-r参数在生产中用的很少，没什么需求-e进去编辑即可
```
- [ ] 计划任务的执行注意事项：
```
1.命令输出必须要带重定向
2.命令必须要先测试，再写入crontab
3.计划任务中，%必须转义
4.计划任务必须写注释
```

---


### 练习：
- [x] 每隔5分钟同步一次系统时间。

时间同步：
```
yum install -y ntpdate

crontab -e
*/5 * * * * /usr/sbin/ntpdate ntp1.aliyun.com &>/dev/null
```
- [x] 2.备份/etc/hosts文件，要求每天保留一个副本，每天晚上0点执行。
```
解题思路：
1.先在命令行测试cp /etc/hosts /tmp/hosts_$(date +\%F).bak
2.编辑crontab#backup /etc/hosts00 00 * * * /usr/bin/cp /etc/hosts /tmp/hosts_$(date +\%F).bak
```
- [x] 3.备份/etc/hosts,/etc/rc.local,/var/spool/cron/root文件，要求每天保留一个副本，每天凌晨3点15分执行。
```
1.先在命令行测试tar czf /tmp/bak_$(date +\%F).tar.gz /etc/hosts /etc/rc.local /var/spool/cron/root
2.编辑crontab
#backup /etc/hosts,/etc/rc.local,/var/spool/cron/root
15 03 * * * /usr/bin/tar czf /tmp/bak_$(date +\%F).tar.gz /etc/hosts /etc/rc.local /var/spool/cron/root
```
思考题：
通过crontab实现一个时间节点操作多条指令，会出现什么问题？


---


### 练习整理

- [ ] 解释下列每行时间含义
```
a. 0 13,20 * 1,2,3,4,5 *  /bin/sh backup.s        #每年的1月至5月，每天13整点，20整点执行
b. 0 13,20 1,5 * *        /bin/sh backup.sh 	·	#每月的1至5日13整点，20整点执行
c. * 13,20 * * 1,2,3,4,5  /bin/sh backup.sh       	#每周一之周五13点，20点每分钟执行
d. 0 13,20 * * 1,2,3,4,5  /bin/sh backup.sh	  	#每周一之周五13整点，20整点执行
2.新建/soft/scripts/httpd.sh文件，并让/soft/scripts/httpd.sh脚本在每天的00:10分执行
#10 00 * * * /usr/bin/bash /soft/scripts/httpd.sh &> /dev/null
3.新建/backup目录,每周一下午5:50将/backup目录下的所有文件打包成 backup.tar.gz
#50  17  * * 1 /usr/bin/tar zcf back.tar.gz  /backup/  &> /dev/nul
4.书写一个定时任务，每天0点0分把/var/log/nginx下大于7天文件转移到/backup/2018_xx_xx的目录中
#00  00 * * * /usr/bin/find  /var/log/nginx  -type f -mtine +7 -exec mv {} /backup/2018_xx_xx \;
#00  00 * * * /usr/bin/find  /var/log/nginx  -type f -mtime +7 | xargs -I {} mv {} /tmp/2018_xx_xx
5.系统脚本/soft/scripts/which.sh，如何定时每隔7分钟执行一次？
#*/7  * * * *  /usr/bin/bash  /soft/scripts/which.sh
```
### 提示：
> /dev/null 2>&1 等价于 1>/dev/null 2>/dev/null  等价于&>/dev/null

6.如何不小心删除了/var/spool/cron/root文件，该如何恢复。
提示：通过日志文件
```
[root@luqyf cron]# cat /var/log/cron | grep -i "root" | grep "CMD"  | awk -F '(' '{print $3}'  | awk -F ')' '{print $1}' | uniq > cmd_tmp
```

---

#### 书写规范：
```
1）为定时任务规则加必要的注释
2）执行shell脚本任务前加/bin/bash
3)  定时任务命令或脚本结尾加&>/dev/null
4）定时任务命令或程序最好写到脚本里执行
5）在指定用户下执行相关定时任务
6）生产任务程序不要随意打印输出信息 tar zcf echo 123 > a.log
7）定时任务执行的脚本要规范路径8）配置定时任务规范操作过程
```

- [ ] 工作中调试定时任务的方法：
```
1、增加执行任务频率调试任务（某些任务不能用于生产环境）
2、调整系统时间调试任务（不能用于生产环境）
3、通过脚本日志输出调试定时任务
4、注意一些任务命令带来的问题（*/1 * * * * echo "==" >> /tmp/oldboy.log &> /dev/null 5、注意环境变量导致定时任务故障
6、通过crond定时任务服务日志调试定时任务
7、其他稀奇古怪的问题调试方法
```

- [ ] crond任务生产应用10箴言：
```
1、系统环境变量问题
2、定时任务要用绝对路径
3、脚本权限问题加/bin/sh
4、时间变量问题用转义\%
5、&>/dev/null问题（1> /dev/null 2>.dev.null）
6、定时任务规则之前加注释
7、使用脚本程序替代命令行定时任务
8、避免不必要的程序及命令输出
9、切到目标目录上的上一级打包目标
10、定时任务脚本中的程序使用全路径
```












